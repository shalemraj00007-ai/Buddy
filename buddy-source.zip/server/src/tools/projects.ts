import { createProject } from '../services/projects';
import { ToolContext, ToolResult } from './types';

export async function projectsTool(ctx: ToolContext, args: Record<string, unknown>): Promise<ToolResult> {
  const name = String(args.name ?? '').trim();
  if (!name) return { ok: false, text: 'No project name provided.' };
  const p = createProject(ctx.userId, { name });
  return { ok: true, text: `Created project "${p.name}".` };
}
