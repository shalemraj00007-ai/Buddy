import { ToolContext, ToolResult } from './types';
import { memoryTool } from './memory';
import { tasksTool } from './tasks';
import { remindersTool } from './reminders';
import { projectsTool } from './projects';
import { calculatorTool, timeTool } from './misc';
import { webSearchTool } from './webSearch';

export * from './types';

/**
 * Central registry of all tools. Adding a tool here makes it available to the
 * AI orchestration. Each tool is a small, independent module.
 */
export const registry: Record<string, (ctx: ToolContext, args: Record<string, unknown>) => Promise<ToolResult>> = {
  memory: memoryTool,
  tasks: tasksTool,
  reminders: remindersTool,
  projects: projectsTool,
  calculator: calculatorTool,
  time: timeTool,
  web_search: webSearchTool,
};

export function toolNames(): string[] {
  return Object.keys(registry);
}

export async function runTool(
  name: string,
  ctx: ToolContext,
  args: Record<string, unknown>,
): Promise<ToolResult> {
  const fn = registry[name];
  if (!fn) return { ok: false, text: `Unknown tool: ${name}` };
  try {
    return await fn(ctx, args);
  } catch (e) {
    return { ok: false, text: `Tool ${name} failed: ${e instanceof Error ? e.message : String(e)}` };
  }
}
