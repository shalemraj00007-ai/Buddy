import { createTask, listTasks, updateTask } from '../services/tasks';
import { ToolContext, ToolResult } from './types';

export async function tasksTool(ctx: ToolContext, args: Record<string, unknown>): Promise<ToolResult> {
  const action = String(args.action ?? 'create');
  const title = String(args.title ?? '').trim();

  if (action === 'create') {
    if (!title) return { ok: false, text: 'No task title provided.' };
    const t = createTask(ctx.userId, {
      title,
      priority: (args.priority as any) || 'medium',
      due_date: args.due_date ? String(args.due_date) : null,
    });
    return {
      ok: true,
      text: `Created task "${t.title}"${t.due_date ? ` due ${t.due_date}` : ''} (${t.priority} priority).`,
    };
  }

  if (action === 'complete') {
    const found = listTasks(ctx.userId, { search: title });
    if (!found.length) return { ok: false, text: `No task found matching "${title}".` };
    updateTask(ctx.userId, found[0].task_id, { status: 'completed' });
    return { ok: true, text: `Marked "${found[0].title}" as completed. ✅` };
  }

  if (action === 'list') {
    const ts = listTasks(ctx.userId, { status: 'todo' }).slice(0, 10);
    if (!ts.length) return { ok: true, text: 'You have no open tasks.' };
    return {
      ok: true,
      text: `Open tasks:\n${ts.map((t) => `- ${t.title}${t.due_date ? ` (due ${t.due_date})` : ''}`).join('\n')}`,
    };
  }

  return { ok: false, text: `Unknown tasks action: ${action}` };
}
