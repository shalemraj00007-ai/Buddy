import { searchConfigured, searchWeb } from '../services/search';
import { ToolContext, ToolResult } from './types';

export async function webSearchTool(_ctx: ToolContext, args: Record<string, unknown>): Promise<ToolResult> {
  const query = String(args.query ?? '').trim();
  if (!query) return { ok: false, text: 'No search query provided.' };
  if (!searchConfigured()) {
    return {
      ok: false,
      text: 'Web search isn’t configured on the server yet. Add a search provider + key in `.env`.',
    };
  }
  try {
    const results = await searchWeb(query);
    if (!results.length) return { ok: true, text: `No results found for "${query}".` };
    return {
      ok: true,
      text:
        `Web results for "${query}":\n` +
        results
          .slice(0, 5)
          .map((r, i) => `${i + 1}. ${r.title}\n   ${r.url}\n   ${r.snippet.slice(0, 180)}`)
          .join('\n'),
    };
  } catch (e) {
    return { ok: false, text: `Search failed: ${e instanceof Error ? e.message : String(e)}` };
  }
}
