import { ToolContext, ToolResult } from './types';

// Safe arithmetic evaluator (no eval of arbitrary JS).
export function safeCalc(expr: string): string {
  const cleaned = expr.replace(/[^0-9+\-*/().\s^%]/g, '').replace(/\^/g, '**');
  if (!cleaned || cleaned.length > 200) return 'Invalid expression.';
  const allowed = /^[0-9+\-*/().\s**%]+$/;
  if (!allowed.test(cleaned)) return 'Expression contains unsupported characters.';
  // eslint-disable-next-line no-new-func
  try {
    const result = new Function(`"use strict"; return (${cleaned});`)();
    if (typeof result === 'number' && Number.isFinite(result)) {
      return `${expr} = ${Number.isInteger(result) ? result : result.toFixed(6)}`;
    }
    return 'Could not evaluate that expression.';
  } catch {
    return 'Could not evaluate that expression.';
  }
}

export async function calculatorTool(_ctx: ToolContext, args: Record<string, unknown>): Promise<ToolResult> {
  const expr = String(args.expression ?? args.expr ?? '').trim();
  if (!expr) return { ok: false, text: 'No expression provided.' };
  return { ok: true, text: safeCalc(expr) };
}

export async function timeTool(_ctx: ToolContext, _args: Record<string, unknown>): Promise<ToolResult> {
  const now = new Date();
  return {
    ok: true,
    text: `Current time: ${now.toLocaleString()}`,
  };
}
