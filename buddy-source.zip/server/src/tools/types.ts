export interface ToolContext {
  userId: string;
  userName: string;
}

export interface ToolResult {
  ok: boolean;
  text: string;
}
