import { createReminder } from '../services/reminders';
import { toIsoTimestamp } from '../lib/dates';
import { ToolContext, ToolResult } from './types';

export async function remindersTool(ctx: ToolContext, args: Record<string, unknown>): Promise<ToolResult> {
  const title = String(args.title ?? '').trim();
  if (!title) return { ok: false, text: 'No reminder title provided.' };
  const at = args.at ? String(args.at) : null;
  const remindAt = toIsoTimestamp(at);
  const r = createReminder(ctx.userId, { title, remind_at: remindAt });
  return {
    ok: true,
    text: `Reminder set: "${r.title}"${remindAt ? ` at ${new Date(remindAt).toLocaleString()}` : ''}.`,
  };
}
