import { createMemory, MEMORY_CATEGORIES, MemoryCategory } from '../memory/service';
import { ToolContext, ToolResult } from './types';

export async function memoryTool(ctx: ToolContext, args: Record<string, unknown>): Promise<ToolResult> {
  const content = String(args.content ?? '').trim();
  if (!content) return { ok: false, text: 'No memory content provided.' };
  const catRaw = String(args.category ?? 'Important fact');
  const category = (MEMORY_CATEGORIES as readonly string[]).includes(catRaw)
    ? (catRaw as MemoryCategory)
    : 'Important fact';
  const mem = createMemory(ctx.userId, { category, content });
  return { ok: true, text: `Saved to memory (${category}): ${content}` };
}
