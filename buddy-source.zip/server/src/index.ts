import { createApp } from './app';
import { config, isProd } from './config';
import { getDb } from './db';
import { startScheduler } from './services/scheduler';

const app = createApp();
getDb(); // initialize DB early
startScheduler();

const server = app.listen(config.port, '0.0.0.0', () => {
  console.log(`[Buddy] API listening on http://0.0.0.0:${config.port}`);
  console.log(`[Buddy] AI provider: ${config.ai.provider} (${isProd ? 'prod' : 'dev'})`);
  console.log(`[Buddy] DB: ${config.dbFile}`);
});

process.on('SIGTERM', () => server.close());
process.on('SIGINT', () => server.close());
