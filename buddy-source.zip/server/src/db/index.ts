import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

import { config } from '../config';
import { migrate } from './schema';

export type DB = Database.Database;

let _db: DB | null = null;

export function getDb(): DB {
  if (_db) return _db;
  fs.mkdirSync(path.dirname(config.dbFile), { recursive: true });
  const db = new Database(config.dbFile);
  db.pragma('journal_mode = WAL');
  migrate(db);
  _db = db;
  return db;
}

export function closeDb(): void {
  if (_db) {
    _db.close();
    _db = null;
  }
}
