import type Database from 'better-sqlite3';

/**
 * The entire SQLite schema. Every table is scoped to a user via
 * {user_id} so users can never see each other's data (enforced in
 * queries, not just in the schema).
 */
export function migrate(db: Database.Database): void {
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    user_id            TEXT PRIMARY KEY,
    email              TEXT NOT NULL UNIQUE,
    name               TEXT NOT NULL,
    password_hash      TEXT NOT NULL,
    language           TEXT NOT NULL DEFAULT 'en',
    theme              TEXT NOT NULL DEFAULT 'system',
    ai_personality     TEXT NOT NULL DEFAULT 'balanced',
    memory_enabled     INTEGER NOT NULL DEFAULT 1,
    voice_enabled      INTEGER NOT NULL DEFAULT 0,
    voice_id           TEXT,
    notifications_enabled INTEGER NOT NULL DEFAULT 1,
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS conversations (
    conversation_id    TEXT PRIMARY KEY,
    user_id            TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    title              TEXT NOT NULL DEFAULT 'New chat',
    archived           INTEGER NOT NULL DEFAULT 0,
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_conversations_user ON conversations(user_id, updated_at);

  CREATE TABLE IF NOT EXISTS messages (
    message_id         TEXT PRIMARY KEY,
    conversation_id    TEXT NOT NULL REFERENCES conversations(conversation_id) ON DELETE CASCADE,
    user_id            TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    role               TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
    content            TEXT NOT NULL DEFAULT '',
    error              TEXT,
    model              TEXT,
    timestamp          TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conversation_id, timestamp);

  CREATE TABLE IF NOT EXISTS attachments (
    attachment_id      TEXT PRIMARY KEY,
    user_id            TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    message_id         TEXT REFERENCES messages(message_id) ON DELETE CASCADE,
    kind               TEXT NOT NULL,            -- 'image' | 'document'
    filename           TEXT NOT NULL,
    mime               TEXT NOT NULL,
    path               TEXT NOT NULL,
    size               INTEGER NOT NULL,
    text_content       TEXT,                     -- extracted text for documents
    created_at         TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_attachments_user ON attachments(user_id);

  CREATE TABLE IF NOT EXISTS memories (
    memory_id          TEXT PRIMARY KEY,
    user_id            TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    category           TEXT NOT NULL,            -- Profile|Preference|Goal|Project|Skill|Important fact|Habit|Context
    content            TEXT NOT NULL,
    importance         INTEGER NOT NULL DEFAULT 3, -- 1..5
    source_conversation_id TEXT,
    metadata           TEXT NOT NULL DEFAULT '{}',
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_memories_user ON memories(user_id, updated_at);

  CREATE TABLE IF NOT EXISTS projects (
    project_id         TEXT PRIMARY KEY,
    user_id            TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    name               TEXT NOT NULL,
    description        TEXT NOT NULL DEFAULT '',
    status             TEXT NOT NULL DEFAULT 'active', -- active|paused|completed|archived
    color              TEXT NOT NULL DEFAULT '#4F8CFF',
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);

  CREATE TABLE IF NOT EXISTS tasks (
    task_id            TEXT PRIMARY KEY,
    user_id            TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    project_id         TEXT REFERENCES projects(project_id) ON DELETE SET NULL,
    title              TEXT NOT NULL,
    description        TEXT NOT NULL DEFAULT '',
    priority           TEXT NOT NULL DEFAULT 'medium', -- low|medium|high
    due_date           TEXT,
    status             TEXT NOT NULL DEFAULT 'todo',    -- todo|in_progress|completed
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL,
    completed_at       TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(user_id, status, due_date);

  CREATE TABLE IF NOT EXISTS reminders (
    reminder_id        TEXT PRIMARY KEY,
    user_id            TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    title              TEXT NOT NULL,
    note               TEXT NOT NULL DEFAULT '',
    remind_at          TEXT,                       -- one-time ISO timestamp (or next fire for recurring)
    recurring          TEXT,                       -- JSON: {type:'daily'|'weekly'|'monthly', at:'HH:MM', days:[0-6]} or null
    enabled            INTEGER NOT NULL DEFAULT 1,
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL,
    last_fired_at      TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_reminders_user ON reminders(user_id, enabled, remind_at);
  `);
}
