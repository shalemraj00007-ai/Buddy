export type Role = 'system' | 'user' | 'assistant';

export interface AIContentPart {
  type: 'text' | 'image_url' | 'file';
  text?: string;
  image_url?: string; // base64 data URI
}

export interface AIMessage {
  role: Role;
  content: string | AIContentPart[];
}

export interface ChatOptions {
  /** Model to use; falls back to provider default when omitted. */
  model?: string;
  /** Present images (base64 data URIs) or extracted file text. */
  parts?: { images?: string[]; files?: string[] };
  /** Softly bound to a temperature preference. */
  temperature?: number;
  /** Stop the request after this many seconds. */
  timeoutMs?: number;
}

export interface ToolDef {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

export interface ToolCall {
  name: string;
  arguments: Record<string, unknown>;
}

export interface ChatResult {
  text: string;
  /** Tool calls requested by the model (if it supports tool calling). */
  toolCalls: ToolCall[];
}

export interface ModelInfo {
  name: string;
}

/** Unified contract every AI provider implements. */
export interface AIProvider {
  readonly id: string;
  readonly label: string;
  /** True when the provider is configured and usable. */
  isConfigured(): boolean;
  /** Human-readable reason when not configured. */
  whyNotConfigured(): string;
  /** Streaming chat. Calls onChunk for each text delta. */
  chat(
    messages: AIMessage[],
    options: ChatOptions,
    onChunk: (delta: string) => void,
  ): Promise<ChatResult>;
  /** Ask a vision model about one or more images. */
  vision(
    prompt: string,
    images: string[],
    model?: string,
  ): Promise<string>;
  /** List available models (used by settings). */
  listModels(): Promise<ModelInfo[]>;
  /** Names of available tools the provider can call, if supported. */
  supportedTools(): string[];
}
