import { config } from '../../config';
import type {
  AIProvider,
  AIMessage,
  ChatOptions,
  ChatResult,
  ModelInfo,
  ToolDef,
  ToolCall,
} from '../types';

const ALL_TOOLS = ['memory', 'tasks', 'reminders', 'projects', 'web_search'];

/**
 * OpenAI-compatible provider (OpenAI, or any compatible endpoint).
 * Requires OPENAI_API_KEY. Supports vision and tool calling.
 */
export class OpenAIProvider implements AIProvider {
  readonly id = 'openai';
  readonly label = 'OpenAI-compatible';

  isConfigured(): boolean {
    return !!config.ai.openai.apiKey;
  }

  whyNotConfigured(): string {
    return 'Set OPENAI_API_KEY in the server environment to enable this provider.';
  }

  supportedTools(): string[] {
    return ALL_TOOLS;
  }

  private baseUrl() {
    return config.ai.openai.baseUrl.replace(/\/+$/, '');
  }

  private toContent(m: AIMessage) {
    if (typeof m.content === 'string') return m.content;
    return m.content.map((p) => {
      if (p.type === 'image_url') return { type: 'image_url', image_url: { url: p.image_url } };
      return { type: 'text', text: p.text ?? '' };
    });
  }

  async chat(
    messages: AIMessage[],
    options: ChatOptions,
    onChunk: (delta: string) => void,
  ): Promise<ChatResult> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), options.timeoutMs ?? 120_000);

    const toolDefs: ToolDef[] = [
      {
        name: 'tasks',
        description: 'Create, complete, or update user tasks.',
        parameters: { action: 'string', title: 'string', status: 'string' },
      },
      {
        name: 'reminders',
        description: 'Create or update reminders.',
        parameters: { action: 'string', title: 'string', at: 'string' },
      },
      {
        name: 'memory',
        description: 'Store an important fact about the user.',
        parameters: { action: 'string', content: 'string', category: 'string' },
      },
      {
        name: 'projects',
        description: 'Create a new project.',
        parameters: { action: 'string', name: 'string' },
      },
      {
        name: 'web_search',
        description: 'Search the web for current information.',
        parameters: { query: 'string' },
      },
    ];

    const body: any = {
      model: options.model || config.ai.openai.model,
      messages: messages.map((m) => ({ role: m.role, content: this.toContent(m) })),
      stream: true,
      temperature: options.temperature ?? 0.7,
      tools: toolDefs.map((t) => ({
        type: 'function',
        function: { name: t.name, description: t.description, parameters: { type: 'object', properties: t.parameters } },
      })),
    };

    try {
      const res = await fetch(`${this.baseUrl()}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${config.ai.openai.apiKey}`,
        },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      if (!res.ok || !res.body) {
        const t = await res.text().catch(() => '');
        throw new Error(`AI provider responded ${res.status}: ${t.slice(0, 200)}`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let fullText = '';
      const toolCalls: ToolCall[] = [];

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const line of lines) {
          const t = line.trim();
          if (!t.startsWith('data:')) continue;
          const payload = t.slice(5).trim();
          if (payload === '[DONE]') continue;
          try {
            const data = JSON.parse(payload);
            const delta = data.choices?.[0]?.delta;
            if (delta?.content) {
              fullText += delta.content;
              onChunk(delta.content);
            }
            if (delta?.tool_calls) {
              for (const tc of delta.tool_calls) {
                const idx = tc.index ?? toolCalls.length - 1;
                if (!toolCalls[idx]) {
                  toolCalls[idx] = { name: tc.function?.name ?? '', arguments: {} };
                }
                if (tc.function?.name) toolCalls[idx].name = tc.function.name;
                if (tc.function?.arguments) {
                  try {
                    toolCalls[idx].arguments = JSON.parse(tc.function.arguments);
                  } catch {
                    // partial args accumulate; attempt merge
                  }
                }
              }
            }
          } catch {
            // ignore
          }
        }
      }
      return { text: fullText.trim(), toolCalls };
    } finally {
      clearTimeout(timeout);
    }
  }

  async vision(
    prompt: string,
    images: string[],
    model?: string,
  ): Promise<string> {
    const m = model || config.ai.openai.visionModel;
    const content = [
      { type: 'text', text: prompt },
      ...images.map((url) => ({ type: 'image_url', image_url: { url } })),
    ];
    const res = await fetch(`${this.baseUrl()}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${config.ai.openai.apiKey}`,
      },
      body: JSON.stringify({ model: m, messages: [{ role: 'user', content }] }),
    });
    if (!res.ok) throw new Error(`Vision request failed with status ${res.status}.`);
    const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return (data.choices?.[0]?.message?.content ?? '').trim();
  }

  async listModels(): Promise<ModelInfo[]> {
    const res = await fetch(`${this.baseUrl()}/models`, {
      headers: { Authorization: `Bearer ${config.ai.openai.apiKey}` },
    });
    if (!res.ok) return [];
    const data = (await res.json()) as { data?: { id: string }[] };
    return (data.data ?? []).map((m) => ({ name: m.id }));
  }
}
