import type {
  AIProvider,
  AIMessage,
  ChatOptions,
  ChatResult,
  ModelInfo,
} from '../types';

/**
 * Placeholder provider used when no model is configured. It doesn't fake an
 * AI response — it streams a clear explanation of how to enable a real model
 * so the app is still usable end-to-end.
 */
export class NoneProvider implements AIProvider {
  readonly id = 'none';
  readonly label = 'No model configured';

  isConfigured(): boolean {
    return false;
  }

  whyNotConfigured(): string {
    return 'No AI provider is configured on the server.';
  }

  supportedTools(): string[] {
    return [];
  }

  async chat(
    _messages: AIMessage[],
    _options: ChatOptions,
    onChunk: (d: string) => void,
  ): Promise<ChatResult> {
    const text =
      "I'm not connected to a model yet, so I can't write a real answer — " +
      'but the rest of Buddy is fully working.\n\n' +
      'To enable my brain, edit the server `.env` file and set:\n\n' +
      '- `AI_PROVIDER=ollama` and run `ollama pull llama3.2` (local, private, no key), **or**\n' +
      '- `AI_PROVIDER=openai` and set `OPENAI_API_KEY`.\n\n' +
      'Then restart the server. Meanwhile, you can still manage tasks, projects, ' +
      'reminders and memories through the side navigation.';
    for (const chunk of text.match(/.{1,8}/gs) || [text]) onChunk(chunk);
    return { text, toolCalls: [] };
  }

  async vision(): Promise<string> {
    return 'Vision is not available because no model is configured.';
  }

  async listModels(): Promise<ModelInfo[]> {
    return [];
  }
}
