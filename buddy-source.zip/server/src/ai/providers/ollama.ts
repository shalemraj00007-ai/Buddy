import { config } from '../../config';
import type {
  AIProvider,
  AIMessage,
  ChatOptions,
  ChatResult,
  ModelInfo,
  ToolDef,
  ToolCall,
} from '../types';

interface OllamaChatMsg {
  role: string;
  content: string;
  images?: string[];
}

const ALL_TOOLS = ['memory', 'tasks', 'reminders', 'projects', 'web_search'];

/**
 * Ollama provider: runs a fully local, private model. No API key required.
 * Uses the /api/chat endpoint with streaming enabled.
 */
export class OllamaProvider implements AIProvider {
  readonly id = 'ollama';
  readonly label = 'Ollama (local)';

  private baseUrl() {
    return config.ai.ollama.baseUrl.replace(/\/+$/, '');
  }

  isConfigured(): boolean {
    // Ollama is "configured" if we can reach it; we treat it as configured
    // and surface connectivity errors at request time.
    return true;
  }

  whyNotConfigured(): string {
    return 'Ollama is selected but could not be reached.';
  }

  supportedTools(): string[] {
    return ALL_TOOLS;
  }

  private toMsg(m: AIMessage): OllamaChatMsg {
    if (typeof m.content === 'string') return { role: m.role, content: m.content };
    const text = m.content
      .filter((p) => p.type === 'text')
      .map((p) => p.text)
      .join('\n');
    const images = m.content
      .filter((p) => p.type === 'image_url')
      .map((p) => p.image_url!.split(',')[1]); // strip data URI header
    return { role: m.role, content: text, images: images.length ? images : undefined };
  }

  async chat(
    messages: AIMessage[],
    options: ChatOptions,
    onChunk: (delta: string) => void,
  ): Promise<ChatResult> {
    const base = this.baseUrl();
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), options.timeoutMs ?? 120_000);
    const body: any = {
      model: options.model || config.ai.ollama.model,
      messages: messages.map((m) => this.toMsg(m)),
      stream: true,
      options: { temperature: options.temperature ?? 0.7 },
    };

    try {
      const res = await fetch(`${base}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal,
      });
      if (!res.ok || !res.body) {
        const t = await res.text().catch(() => '');
        throw new Error(
          `Ollama server responded ${res.status}. Is Ollama running and is the model pulled? ${t.slice(0, 200)}`,
        );
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let fullText = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const line of lines) {
          const t = line.trim();
          if (!t) continue;
          try {
            const data = JSON.parse(t);
            if (data.done) continue;
            const delta = data.message?.content ?? '';
            if (delta) {
              fullText += delta;
              onChunk(delta);
            }
          } catch {
            // ignore partial/invalid lines
          }
        }
      }
      return { text: fullText.trim(), toolCalls: [] };
    } finally {
      clearTimeout(timeout);
    }
  }

  async vision(
    prompt: string,
    images: string[],
    model?: string,
  ): Promise<string> {
    const base = this.baseUrl();
    const m = model || config.ai.ollama.visionModel;
    const msg = {
      role: 'user' as const,
      content: prompt,
      images: images.map((i) => i.split(',')[1]),
    };
    const res = await fetch(`${base}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: m, messages: [msg], stream: false }),
    });
    if (!res.ok) {
      throw new Error(`Vision request failed with status ${res.status}.`);
    }
    const data = (await res.json()) as { message?: { content?: string } };
    return (data.message?.content ?? '').trim();
  }

  async listModels(): Promise<ModelInfo[]> {
    const res = await fetch(`${this.baseUrl()}/api/tags`);
    if (!res.ok) throw new Error(`Could not reach Ollama (${res.status}).`);
    const data = (await res.json()) as { models?: { name: string }[] };
    return (data.models ?? []).map((m) => ({ name: m.name }));
  }
}
