import { config } from '../config';
import type { AIProvider } from './types';
import { OllamaProvider } from './providers/ollama';
import { OpenAIProvider } from './providers/openai';
import { NoneProvider } from './providers/none';

let _current: AIProvider | null = null;

export function getAI(): AIProvider {
  if (_current) return _current;
  switch (config.ai.provider) {
    case 'ollama':
      _current = new OllamaProvider();
      break;
    case 'openai':
      _current = new OpenAIProvider();
      break;
    default:
      _current = new NoneProvider();
  }
  return _current;
}

/** Reset singleton (useful in tests). */
export function resetAI(): void {
  _current = null;
}

export function availableProviders(): { id: string; label: string; configured: boolean }[] {
  return [new OllamaProvider(), new OpenAIProvider(), new NoneProvider()].map((p) => ({
    id: p.id,
    label: p.label,
    configured: p.isConfigured(),
  }));
}

export type { AIProvider };
