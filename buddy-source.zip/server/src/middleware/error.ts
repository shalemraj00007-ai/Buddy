import { NextFunction, Request, Response } from 'express';

/** Never leak internal details to the client. */
export function errorHandler(err: any, _req: Request, res: Response, _next: NextFunction) {
  console.error('Unhandled error:', err);
  const status = err.status || 500;
  const message =
    err.expose && err.message ? err.message : 'An unexpected error occurred.';
  res.status(status).json({ error: message });
}

/** Wrap async route handlers so thrown errors reach the error middleware. */
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<any>,
) {
  return (req: Request, res: Response, next: NextFunction) => {
    fn(req, res, next).catch(next);
  };
}
