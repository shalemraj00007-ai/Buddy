import { NextFunction, Request, Response } from 'express';

import { getById, PublicUser } from '../auth/service';
import { verifyToken } from '../auth/service';

declare module 'express-serve-static-core' {
  interface Request {
    user?: PublicUser;
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const payload = token ? verifyToken(token) : null;
  if (!payload?.sub) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  const user = getById(payload.sub);
  if (!user) {
    res.status(401).json({ error: 'Account not found.' });
    return;
  }
  req.user = user;
  next();
}
