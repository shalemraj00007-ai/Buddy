import 'dotenv/config';
import path from 'node:path';
import fs from 'node:fs';

function bool(v: string | undefined, dflt: boolean): boolean {
  if (v === undefined) return dflt;
  return ['1', 'true', 'yes', 'on'].includes(v.toLowerCase());
}

const dataDir = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : path.resolve(import.meta.dirname, '../data');

fs.mkdirSync(path.join(dataDir, 'uploads'), { recursive: true });

// Built frontend (web/dist). The server serves it in production so a single
// process runs both the UI and the API.
const webDist =
  process.env.WEB_DIST || path.resolve(import.meta.dirname, '../../web/dist');

export const config = {
  port: Number(process.env.PORT || 4000),
  jwtSecret: process.env.JWT_SECRET || 'dev-only-insecure-secret',
  corsOrigin: (process.env.CORS_ORIGIN || 'http://localhost:5173')
    .split(',')
    .map((s) => s.trim()),
  dataDir,
  uploadsDir: path.join(dataDir, 'uploads'),
  dbFile: path.join(dataDir, 'buddy.db'),
  webDist,

  ai: {
    provider: (process.env.AI_PROVIDER || 'none').toLowerCase(),
    ollama: {
      baseUrl: process.env.OLLAMA_BASE_URL || 'http://localhost:11434',
      model: process.env.OLLAMA_MODEL || 'llama3.2',
      visionModel: process.env.OLLAMA_VISION_MODEL || 'llava',
    },
    openai: {
      apiKey: process.env.OPENAI_API_KEY || '',
      baseUrl: process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1',
      model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
      visionModel: process.env.OPENAI_VISION_MODEL || 'gpt-4o-mini',
    },
  },

  search: {
    provider: (process.env.SEARCH_PROVIDER || 'none').toLowerCase(),
    apiKey: process.env.SEARCH_API_KEY || '',
  },

  limits: {
    maxUploadBytes: 15 * 1024 * 1024, // 15 MB
    maxTextExtractBytes: 3 * 1024 * 1024,
  },
} as const;

export const isProd = process.env.NODE_ENV === 'production';
export const dev = process.env.NODE_ENV !== 'production';
