import { randomUUID } from 'node:crypto';

export const uid = () => randomUUID();

export function nowIso(): string {
  return new Date().toISOString();
}
