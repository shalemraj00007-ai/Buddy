/**
 * Parse loosely-specified reminder times ("19:00", "tomorrow at 8am",
 * "2026-08-12", a full ISO timestamp) into an absolute ISO string for the
 * next relevant occurrence.
 */
export function toIsoTimestamp(input: string | null): string | null {
  if (!input) return null;
  const raw = input.trim();

  // Already a full ISO timestamp.
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(raw)) {
    const t = new Date(raw);
    return isNaN(t.getTime()) ? null : t.toISOString();
  }

  const now = new Date();
  const at = /(\d{1,2}):(\d{2})\s*(am|pm)?/i.exec(raw);
  let date = new Date(now);

  if (/\btomorrow\b/i.test(raw)) date.setDate(date.getDate() + 1);

  if (at) {
    let h = Number(at[1]);
    const m = Number(at[2]);
    const ampm = at[3]?.toLowerCase();
    if (ampm === 'pm' && h < 12) h += 12;
    if (ampm === 'am' && h === 12) h = 0;
    date.setHours(h, m, 0, 0);
    // If that time is already past, roll to tomorrow.
    if (date.getTime() <= now.getTime()) date.setDate(date.getDate() + 1);
  } else if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
    // Bare date: end of that day.
    const [y, mo, d] = raw.split('-').map(Number);
    date = new Date(y, mo - 1, d, 23, 59, 0, 0);
  } else {
    // Unknown format: today at the given time if present else end of day.
    date.setHours(23, 59, 0, 0);
  }

  return date.toISOString();
}
