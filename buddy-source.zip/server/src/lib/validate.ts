import { z } from 'zod';

export const emailSchema = z.string().trim().email().max(200);
export const passwordSchema = z.string().min(6).max(200);
export const nameSchema = z.string().trim().min(1).max(100);

export function parseError(e: unknown): string {
  if (e instanceof z.ZodError) {
    return e.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ');
  }
  return e instanceof Error ? e.message : String(e);
}
