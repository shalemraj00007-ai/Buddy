/**
 * Lightweight memory retrieval.
 *
 * This is a local, dependency-free relevance scorer used as the default
 * retrieval backend. It is intentionally isolated behind this module so a real
 * vector/semantic store (e.g. sqlite-vec, pgvector, a local embedding model)
 * can be plugged in later without touching the rest of the system.
 */

export interface MemoryRecord {
  memory_id: string;
  user_id: string;
  category: string;
  content: string;
  importance: number;
  metadata: string;
  created_at: string;
  updated_at: string;
}

/** Very small English stopword list to keep scoring meaningful. */
const STOP = new Set(
  ('a an the is are was were be been being do does did have has had ' +
    'i you he she it we they me my your his her our their this that these those ' +
    'to of in on at for with and or but not no so if then than as from by about ' +
    'can could will would should shall may might what which who whom when where why how ' +
    'just please really want need').split(' '),
);

export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/gi, ' ')
    .split(/\s+/)
    .filter((t) => t.length > 1 && !STOP.has(t));
}

export function scoreMemory(queryTokens: string[], mem: MemoryRecord): number {
  const memTokens = tokenize(mem.content);
  const memSet = new Set(memTokens);
  let overlap = 0;
  for (const q of queryTokens) {
    if (memSet.has(q)) overlap += 1;
    // substring match for multi-word concepts
    for (const m of memTokens) {
      if (m.length > 4 && m.includes(q)) overlap += 0.5;
    }
  }
  const overlapScore = memTokens.length ? overlap / Math.sqrt(memTokens.length) : 0;
  const importanceBoost = (mem.importance - 1) * 0.4;
  // recency decay
  const ageHours =
    (Date.now() - new Date(mem.updated_at).getTime()) / (1000 * 60 * 60);
  const recency = Math.max(0, 1 - ageHours / (24 * 30)); // ~30 day half-decay
  return overlapScore + importanceBoost + recency * 0.1;
}

export function retrieveRelevant(
  query: string,
  memories: MemoryRecord[],
  limit = 5,
): MemoryRecord[] {
  if (!memories.length) return [];
  const tokens = tokenize(query);
  if (!tokens.length) return [];
  return memories
    .map((m) => ({ m, score: scoreMemory(tokens, m) }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((x) => x.m);
}
