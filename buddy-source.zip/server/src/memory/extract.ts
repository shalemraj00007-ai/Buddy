import { MEMORY_CATEGORIES, MemoryCategory } from './service';

/**
 * Decides whether a user message contains a fact worth remembering.
 *
 * This is a rule-based extractor — deliberately conservative so we don't store
 * every message. A more sophisticated model-backed extractor can replace it
 * later (same function signature) without touching the pipeline.
 */

export interface CandidateMemory {
  category: MemoryCategory;
  content: string;
  importance: number;
}

const PREF_PATTERNS: [RegExp, string][] = [
  [/i (prefer|like|love|enjoy|prefer to)/i, 'Preference'],
  [/i (dislike|don'?t like|hate)/i, 'Preference'],
  [/i (usually|typically|always|never|sometimes)/i, 'Habit'],
];

const PROFILE_PATTERNS: RegExp[] = [
  /my name is/i,
  /i am (a |an )?(student|developer|engineer|designer|researcher|teacher|freelancer|entrepreneur)/i,
  /i'?m (studying|working|learning|based in)/i,
  /i (live|work) in/i,
];

const GOAL_PATTERNS: RegExp[] = [
  /i want to (build|create|learn|become|start|finish|get|make)/i,
  /my (goal|dream|target) is/i,
  /i'?m (trying|planning|aiming) to/i,
  /i (want|need) to (learn|master|improve|complete)/i,
];

const SKILL_PATTERNS: RegExp[] = [
  /i (know|am good at|have experience (with|in)|use) (python|javascript|typescript|react|node|sql|linux|excel|figma|c|java|go|rust|docker|aws|git|crypto|networking|pentest)/i,
  /i'?m (fluent|comfortable|proficient|experienced) (in|with)/i,
];

const PROJECT_PATTERNS: RegExp[] = [
  /i'?m (working on|building|developing|creating|making) (a |an |my )?/i,
  /my (project|side project|startup)/i,
];

function pick(query: string, patterns: RegExp[]): boolean {
  return patterns.some((p) => p.test(query));
}

function sentence(text: string, subject: string): string {
  // Normalize to a clean memory statement, drop the "remember" framing.
  const t = text.trim().replace(/^(please |can you |kindly |also )*/i, '');
  return `${subject} ${t}`.replace(/\s+/g, ' ').slice(0, 240);
}

/** Returns memory candidates for a single user message, or [] if none. */
export function extractMemories(userMessage: string): CandidateMemory[] {
  const text = userMessage.trim();
  if (!text || text.length < 8) return [];
  const low = text.toLowerCase();

  // Never store questions, math, or simple conversational fillers.
  if (
    low.startsWith('what') ||
    low.startsWith('why') ||
    low.startsWith('when') ||
    low.startsWith('where') ||
    low.startsWith('who') ||
    /^\d+\s*[+\-*/]\s*\d+/.test(low) ||
    /^(hi|hello|hey|thanks|thank you|ok|okay|good|bye)\b/.test(low)
  ) {
    return [];
  }

  const out: CandidateMemory[] = [];

  if (pick(text, SKILL_PATTERNS)) {
    out.push({ category: 'Skill', content: sentence(text, 'User skill:'), importance: 4 });
  } else if (pick(text, GOAL_PATTERNS)) {
    out.push({ category: 'Goal', content: sentence(text, 'User goal:'), importance: 4 });
  } else if (pick(text, PROJECT_PATTERNS)) {
    out.push({ category: 'Project', content: sentence(text, 'User project:'), importance: 4 });
  }

  for (const [re, cat] of PREF_PATTERNS) {
    if (re.test(text)) {
      out.push({ category: cat as MemoryCategory, content: sentence(text, 'User preference:'), importance: 3 });
      break;
    }
  }

  if (pick(text, PROFILE_PATTERNS)) {
    out.push({ category: 'Profile', content: sentence(text, ''), importance: 3 });
  }

  return out;
}
