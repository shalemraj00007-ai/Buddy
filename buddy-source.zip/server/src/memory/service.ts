import { getDb } from '../db';
import { nowIso, uid } from '../lib/ids';
import { MemoryRecord, retrieveRelevant } from './retrieval';

export const MEMORY_CATEGORIES = [
  'Profile',
  'Preference',
  'Goal',
  'Project',
  'Skill',
  'Important fact',
  'Habit',
  'Context',
] as const;

export type MemoryCategory = (typeof MEMORY_CATEGORIES)[number];

export function memoryEnabled(userId: string): boolean {
  const row = getDb()
    .prepare('SELECT memory_enabled FROM users WHERE user_id = ?')
    .get(userId) as { memory_enabled: number } | undefined;
  return row ? !!row.memory_enabled : false;
}

export function createMemory(
  userId: string,
  input: {
    category: MemoryCategory;
    content: string;
    importance?: number;
    source_conversation_id?: string | null;
    metadata?: Record<string, unknown>;
  },
): MemoryRecord {
  const db = getDb();
  const now = nowIso();
  // De-duplicate: if an identical memory already exists, refresh it instead of
  // creating a second copy.
  const existing = db
    .prepare(
      `SELECT * FROM memories WHERE user_id = ? AND LOWER(content) = LOWER(?)`,
    )
    .get(userId, input.content.trim()) as MemoryRecord | undefined;
  if (existing) {
    db.prepare('UPDATE memories SET updated_at = ?, importance = ? WHERE memory_id = ?').run(
      now,
      Math.max(existing.importance, input.importance ?? 3),
      existing.memory_id,
    );
    return getMemory(userId, existing.memory_id)!;
  }
  const id = uid();
  db.prepare(
    `INSERT INTO memories
       (memory_id, user_id, category, content, importance, source_conversation_id, metadata, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?)`,
  ).run(
    id,
    userId,
    input.category,
    input.content,
    Math.min(5, Math.max(1, input.importance ?? 3)),
    input.source_conversation_id ?? null,
    JSON.stringify(input.metadata ?? {}),
    now,
    now,
  );
  return getMemory(userId, id)!;
}

export function getMemory(userId: string, memoryId: string): MemoryRecord | null {
  const row = getDb()
    .prepare('SELECT * FROM memories WHERE user_id = ? AND memory_id = ?')
    .get(userId, memoryId);
  return row ? (row as MemoryRecord) : null;
}

export function listMemories(userId: string, category?: string): MemoryRecord[] {
  const db = getDb();
  if (category) {
    return db
      .prepare('SELECT * FROM memories WHERE user_id = ? AND category = ? ORDER BY updated_at DESC')
      .all(userId, category) as MemoryRecord[];
  }
  return db
    .prepare('SELECT * FROM memories WHERE user_id = ? ORDER BY updated_at DESC')
    .all(userId) as MemoryRecord[];
}

export function searchMemories(userId: string, query: string): MemoryRecord[] {
  const all = listMemories(userId);
  if (!query.trim()) return all;
  return retrieveRelevant(query, all, all.length);
}

export function updateMemory(
  userId: string,
  memoryId: string,
  fields: Partial<{ category: MemoryCategory; content: string; importance: number }>,
): MemoryRecord | null {
  const db = getDb();
  const sets: string[] = ['updated_at = ?'];
  const vals: unknown[] = [nowIso()];
  if (fields.category !== undefined) {
    sets.push('category = ?');
    vals.push(fields.category);
  }
  if (fields.content !== undefined) {
    sets.push('content = ?');
    vals.push(fields.content);
  }
  if (fields.importance !== undefined) {
    sets.push('importance = ?');
    vals.push(Math.min(5, Math.max(1, fields.importance)));
  }
  vals.push(userId, memoryId);
  const info = db
    .prepare(`UPDATE memories SET ${sets.join(', ')} WHERE user_id = ? AND memory_id = ?`)
    .run(...vals);
  return info.changes ? getMemory(userId, memoryId) : null;
}

export function deleteMemory(userId: string, memoryId: string): boolean {
  const info = getDb()
    .prepare('DELETE FROM memories WHERE user_id = ? AND memory_id = ?')
    .run(userId, memoryId);
  return info.changes > 0;
}

export function deleteAllMemories(userId: string): number {
  const info = getDb().prepare('DELETE FROM memories WHERE user_id = ?').run(userId);
  return info.changes;
}

export function countMemories(userId: string): number {
  const row = getDb()
    .prepare('SELECT COUNT(*) AS c FROM memories WHERE user_id = ?')
    .get(userId) as { c: number };
  return row.c;
}

export { retrieveRelevant };
