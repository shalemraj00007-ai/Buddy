import express from 'express';
import cors from 'cors';
import fs from 'node:fs';
import path from 'node:path';

import { config } from './config';
import { authRouter } from './routes/auth';
import { chatRouter } from './routes/chat';
import { conversationsRouter } from './routes/conversations';
import { memoriesRouter } from './routes/memories';
import { tasksRouter } from './routes/tasks';
import { projectsRouter } from './routes/projects';
import { remindersRouter } from './routes/reminders';
import { filesRouter } from './routes/files';
import { miscRouter } from './routes/misc';
import { errorHandler } from './middleware/error';

export function createApp() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(cors({ origin: config.corsOrigin, credentials: true }));
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => res.json({ ok: true }));
  app.get('/', (_req, res) => res.json({ service: 'Buddy API', status: 'ok' }));

  app.use('/api', authRouter);
  app.use('/api', chatRouter);
  app.use('/api/conversations', conversationsRouter);
  app.use('/api/memories', memoriesRouter);
  app.use('/api/tasks', tasksRouter);
  app.use('/api/projects', projectsRouter);
  app.use('/api/reminders', remindersRouter);
  app.use('/api/files', filesRouter);
  app.use('/api', miscRouter);

  // In production, serve the built frontend so one process runs the whole app.
  const dist = path.join(config.webDist);
  if (fs.existsSync(dist)) {
    app.use(express.static(dist));
    // SPA fallback (must not swallow /api routes, which are mounted above).
    app.get(/^(?!\/api).*/, (_req, res) => {
      res.sendFile(path.join(dist, 'index.html'));
    });
  }

  app.use(errorHandler);
  return app;
}
