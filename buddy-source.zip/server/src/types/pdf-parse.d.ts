declare module 'pdf-parse' {
  interface PdfParseResult {
    text: string;
    numpages: number;
    info: any;
  }
  function pdfParse(buffer: Buffer, options?: { max?: number }): Promise<PdfParseResult>;
  export default pdfParse;
}
