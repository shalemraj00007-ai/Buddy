import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

import { config } from '../config';
import { getDb } from '../db';
import { nowIso, uid } from '../lib/ids';

export interface PublicUser {
  user_id: string;
  email: string;
  name: string;
  language: string;
  theme: string;
  ai_personality: string;
  memory_enabled: boolean;
  voice_enabled: boolean;
  voice_id: string | null;
  notifications_enabled: boolean;
}

type UserRow = PublicUser & { password_hash: string };

export function toPublicUser(row: any): PublicUser {
  return {
    user_id: row.user_id,
    email: row.email,
    name: row.name,
    language: row.language,
    theme: row.theme,
    ai_personality: row.ai_personality,
    memory_enabled: !!row.memory_enabled,
    voice_enabled: !!row.voice_enabled,
    voice_id: row.voice_id,
    notifications_enabled: !!row.notifications_enabled,
  };
}

export async function register(
  email: string,
  password: string,
  name: string,
): Promise<PublicUser> {
  const db = getDb();
  const hash = await bcrypt.hash(password, 10);
  const now = nowIso();
  const userId = uid();
  try {
    db.prepare(
      `INSERT INTO users (user_id, email, name, password_hash, created_at, updated_at)
       VALUES (?,?,?,?,?,?)`,
    ).run(userId, email.toLowerCase(), name, hash, now, now);
  } catch (e: any) {
    if (String(e?.message).includes('UNIQUE')) {
      throw new Error('An account with that email already exists.');
    }
    throw e;
  }
  return getByEmail(email)!;
}

export function getByEmail(email: string): PublicUser | null {
  const row = getDb().prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase());
  return row ? toPublicUser(row) : null;
}

export function getById(userId: string): PublicUser | null {
  const row = getDb().prepare('SELECT * FROM users WHERE user_id = ?').get(userId);
  return row ? toPublicUser(row) : null;
}

export async function verifyPassword(
  email: string,
  password: string,
): Promise<PublicUser | null> {
  const db = getDb();
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase()) as UserRow | undefined;
  if (!row) return null;
  const ok = await bcrypt.compare(password, row.password_hash);
  return ok ? toPublicUser(row) : null;
}

export function signToken(user: PublicUser): string {
  return jwt.sign({ sub: user.user_id }, config.jwtSecret, { expiresIn: '7d' });
}

export function verifyToken(token: string): { sub: string } | null {
  try {
    return jwt.verify(token, config.jwtSecret) as { sub: string };
  } catch {
    return null;
  }
}

export async function updateProfile(
  userId: string,
  fields: Partial<{
    name: string;
    language: string;
    theme: string;
    ai_personality: string;
    memory_enabled: boolean;
    voice_enabled: boolean;
    voice_id: string | null;
    notifications_enabled: boolean;
  }>,
): Promise<PublicUser> {
  const db = getDb();
  const allowed: (keyof typeof fields)[] = [
    'name',
    'language',
    'theme',
    'ai_personality',
    'memory_enabled',
    'voice_enabled',
    'voice_id',
    'notifications_enabled',
  ];
  for (const k of allowed) {
    if (fields[k] !== undefined) {
      const v =
        typeof fields[k] === 'boolean' ? (fields[k] ? 1 : 0) : fields[k];
      db.prepare(`UPDATE users SET ${k} = ?, updated_at = ? WHERE user_id = ?`).run(
        v,
        nowIso(),
        userId,
      );
    }
  }
  return getById(userId)!;
}

export function deleteAccount(userId: string): void {
  getDb().prepare('DELETE FROM users WHERE user_id = ?').run(userId);
}
