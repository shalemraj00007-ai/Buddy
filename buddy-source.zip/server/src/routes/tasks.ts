import { Router } from 'express';
import { z } from 'zod';

import { requireAuth } from '../middleware/auth';
import { asyncHandler } from '../middleware/error';
import * as tasks from '../services/tasks';

export const tasksRouter = Router();
tasksRouter.use(requireAuth);

const taskSchema = z.object({
  title: z.string().min(1).max(300),
  description: z.string().max(2000).optional(),
  priority: z.enum(['low', 'medium', 'high']).optional(),
  due_date: z.string().nullable().optional(),
  status: z.enum(['todo', 'in_progress', 'completed']).optional(),
  project_id: z.string().uuid().nullable().optional(),
});

tasksRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const f = tasks.listTasks(req.user!.user_id, {
      status: typeof req.query.status === 'string' ? (req.query.status as any) : undefined,
      priority: typeof req.query.priority === 'string' ? (req.query.priority as any) : undefined,
      project_id: typeof req.query.project_id === 'string' ? req.query.project_id : undefined,
      search: typeof req.query.search === 'string' ? req.query.search : undefined,
      sort: typeof req.query.sort === 'string' ? (req.query.sort as any) : undefined,
      direction: typeof req.query.direction === 'string' ? (req.query.direction as any) : undefined,
    });
    res.json({ tasks: f });
  }),
);

tasksRouter.get(
  '/overview',
  asyncHandler(async (req, res) => {
    res.json(tasks.tasksOverview(req.user!.user_id));
  }),
);

tasksRouter.post(
  '/',
  asyncHandler(async (req, res) => {
    const parsed = taskSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join('; ') });
      return;
    }
    const t = tasks.createTask(req.user!.user_id, parsed.data);
    res.status(201).json({ task: t });
  }),
);

tasksRouter.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    const parsed = taskSchema.partial().safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid input.' });
      return;
    }
    const t = tasks.updateTask(req.user!.user_id, req.params.id, parsed.data);
    if (!t) {
      res.status(404).json({ error: 'Task not found.' });
      return;
    }
    res.json({ task: t });
  }),
);

tasksRouter.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const ok = tasks.deleteTask(req.user!.user_id, req.params.id);
    if (!ok) {
      res.status(404).json({ error: 'Task not found.' });
      return;
    }
    res.json({ ok: true });
  }),
);
