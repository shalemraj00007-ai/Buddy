import { Router } from 'express';
import fs from 'node:fs';

import { requireAuth } from '../middleware/auth';
import { asyncHandler } from '../middleware/error';
import * as files from '../services/files';

export const filesRouter = Router();
filesRouter.use(requireAuth);

filesRouter.post(
  '/',
  files.upload.array('files', 8),
  asyncHandler(async (req, res) => {
    if (!req.files || (req.files as Express.Multer.File[]).length === 0) {
      res.status(400).json({ error: 'No files uploaded.' });
      return;
    }
    const saved: any[] = [];
    for (const f of req.files as Express.Multer.File[]) {
      saved.push(await files.storeAttachment(req.user!.user_id, f));
    }
    res.status(201).json({ attachments: saved });
  }),
);

filesRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const { getDb } = await import('../db');
    const rows = getDb()
      .prepare('SELECT * FROM attachments WHERE user_id = ? ORDER BY created_at DESC')
      .all(req.user!.user_id);
    res.json({ attachments: rows });
  }),
);

filesRouter.get(
  '/:id/file',
  asyncHandler(async (req, res) => {
    const att = files.getAttachment(req.user!.user_id, req.params.id);
    if (!att || !fs.existsSync(att.path)) {
      res.status(404).json({ error: 'File not found.' });
      return;
    }
    res.sendFile(att.path);
  }),
);

filesRouter.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const att = files.getAttachment(req.user!.user_id, req.params.id);
    if (!att) {
      res.status(404).json({ error: 'Attachment not found.' });
      return;
    }
    res.json({ attachment: att });
  }),
);

filesRouter.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const ok = files.deleteAttachment(req.user!.user_id, req.params.id);
    if (!ok) {
      res.status(404).json({ error: 'Attachment not found.' });
      return;
    }
    res.json({ ok: true });
  }),
);
