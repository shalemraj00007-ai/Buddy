import { Router } from 'express';
import { z } from 'zod';

import { register, verifyPassword, signToken, toPublicUser, updateProfile, deleteAccount } from '../auth/service';
import { requireAuth } from '../middleware/auth';
import { asyncHandler } from '../middleware/error';
import { emailSchema, nameSchema, parseError, passwordSchema } from '../lib/validate';

export const authRouter = Router();

const registerSchema = z.object({ email: emailSchema, password: passwordSchema, name: nameSchema });

authRouter.post(
  '/register',
  asyncHandler(async (req, res) => {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parseError(parsed.error) });
      return;
    }
    try {
      const user = await register(parsed.data.email, parsed.data.password, parsed.data.name);
      res.status(201).json({ user, token: signToken(user) });
    } catch (e) {
      res.status(409).json({ error: e instanceof Error ? e.message : 'Registration failed.' });
    }
  }),
);

authRouter.post(
  '/login',
  asyncHandler(async (req, res) => {
    const parsed = z.object({ email: emailSchema, password: z.string() }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parseError(parsed.error) });
      return;
    }
    const user = await verifyPassword(parsed.data.email, parsed.data.password);
    if (!user) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }
    res.json({ user, token: signToken(user) });
  }),
);

authRouter.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    res.json({ user: toPublicUser(req.user!) });
  }),
);

const settingsSchema = z.object({
  name: nameSchema.optional(),
  language: z.string().max(20).optional(),
  theme: z.enum(['light', 'dark', 'system']).optional(),
  ai_personality: z.enum(['balanced', 'concise', 'detailed', 'technical', 'casual']).optional(),
  memory_enabled: z.boolean().optional(),
  voice_enabled: z.boolean().optional(),
  voice_id: z.string().nullable().optional(),
  notifications_enabled: z.boolean().optional(),
});

authRouter.patch(
  '/settings',
  requireAuth,
  asyncHandler(async (req, res) => {
    const parsed = settingsSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parseError(parsed.error) });
      return;
    }
    const user = await updateProfile(req.user!.user_id, parsed.data);
    res.json({ user: toPublicUser(user) });
  }),
);

authRouter.delete(
  '/account',
  requireAuth,
  asyncHandler(async (req, res) => {
    deleteAccount(req.user!.user_id);
    res.json({ ok: true });
  }),
);

// Expose provider info for the settings screen.
authRouter.get('/providers', asyncHandler(async (_req, res) => {
  const { availableProviders } = await import('../ai');
  res.json({ providers: availableProviders() });
}));
