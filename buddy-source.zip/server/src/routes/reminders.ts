import { Router } from 'express';
import { z } from 'zod';

import { requireAuth } from '../middleware/auth';
import { asyncHandler } from '../middleware/error';
import * as reminders from '../services/reminders';

export const remindersRouter = Router();
remindersRouter.use(requireAuth);

const reminderSchema = z.object({
  title: z.string().min(1).max(300),
  note: z.string().max(2000).optional(),
  remind_at: z.string().nullable().optional(),
  recurring: z
    .object({
      type: z.enum(['daily', 'weekly', 'monthly']),
      at: z.string().optional(),
      days: z.array(z.number().int().min(0).max(6)).optional(),
    })
    .nullable()
    .optional(),
  enabled: z.boolean().optional(),
});

remindersRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const enabledOnly = req.query.enabled === '1';
    res.json({ reminders: reminders.listReminders(req.user!.user_id, enabledOnly) });
  }),
);

remindersRouter.post(
  '/',
  asyncHandler(async (req, res) => {
    const parsed = reminderSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join('; ') });
      return;
    }
    const r = reminders.createReminder(req.user!.user_id, parsed.data);
    res.status(201).json({ reminder: r });
  }),
);

remindersRouter.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    const parsed = reminderSchema.partial().safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid input.' });
      return;
    }
    const r = reminders.updateReminder(req.user!.user_id, req.params.id, parsed.data);
    if (!r) {
      res.status(404).json({ error: 'Reminder not found.' });
      return;
    }
    res.json({ reminder: r });
  }),
);

remindersRouter.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const ok = reminders.deleteReminder(req.user!.user_id, req.params.id);
    if (!ok) {
      res.status(404).json({ error: 'Reminder not found.' });
      return;
    }
    res.json({ ok: true });
  }),
);
