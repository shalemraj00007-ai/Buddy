import { Router } from 'express';
import { z } from 'zod';

import { requireAuth } from '../middleware/auth';
import { asyncHandler } from '../middleware/error';
import { runChat, StreamSink } from '../services/chat';

export const chatRouter = Router();

const schema = z.object({
  conversation_id: z.string().uuid().optional(),
  content: z.string().max(8000).default(''),
  attachment_ids: z.array(z.string().uuid()).optional(),
  regenerate_message_id: z.string().uuid().optional(),
});

function sendSSE(res: any, event: string, data: unknown) {
  res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
}

chatRouter.post(
  '/chat',
  requireAuth,
  asyncHandler(async (req, res) => {
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join('; ') });
      return;
    }

    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.flushHeaders?.();

    let closed = false;
    res.on('close', () => {
      closed = true;
    });

    const sink: StreamSink = {
      meta: (m) => !closed && sendSSE(res, 'meta', m),
      delta: (text) => !closed && sendSSE(res, 'delta', { text }),
      done: (info) => {
        if (closed) return;
        sendSSE(res, 'done', info);
        res.end();
      },
      error: (message) => {
        if (closed) return;
        sendSSE(res, 'error', { message });
        res.end();
      },
    };

    try {
      await runChat(req.user!.user_id, {
        conversationId: parsed.data.conversation_id,
        content: parsed.data.content,
        attachmentIds: parsed.data.attachment_ids,
        regenerateMessageId: parsed.data.regenerate_message_id,
      }, sink);
    } catch (e) {
      console.error('Chat error:', e);
      if (!closed) {
        sendSSE(res, 'error', {
          message: 'Something went wrong generating a reply. Please try again.',
        });
        res.end();
      }
    }
  }),
);
