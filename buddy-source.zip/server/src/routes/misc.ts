import { Router } from 'express';
import { z } from 'zod';
import fs from 'node:fs';

import { requireAuth } from '../middleware/auth';
import { asyncHandler } from '../middleware/error';
import { getDaily } from '../services/daily';
import { getAttachment } from '../services/files';
import { searchWeb, searchConfigured } from '../services/search';
import { getAI } from '../ai';
import { getById } from '../auth/service';
import { listMemories, retrieveRelevant } from '../memory/service';

export const miscRouter = Router();
miscRouter.use(requireAuth);

// --- Daily dashboard ---
miscRouter.get(
  '/daily',
  asyncHandler(async (req, res) => {
    res.json({ daily: getDaily(req.user!.user_id) });
  }),
);

// --- Web search (explicit, from the search UI) ---
miscRouter.post(
  '/search',
  asyncHandler(async (req, res) => {
    const parsed = z.object({ query: z.string().min(1).max(300) }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'A query is required.' });
      return;
    }
    if (!searchConfigured()) {
      res.status(501).json({ error: 'Web search is not configured on the server.' });
      return;
    }
    const results = await searchWeb(parsed.data.query);
    res.json({ results });
  }),
);

// --- Vision / image analysis ---
miscRouter.post(
  '/vision',
  asyncHandler(async (req, res) => {
    const parsed = z
      .object({ attachment_id: z.string().uuid(), prompt: z.string().max(2000).optional() })
      .safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid request.' });
      return;
    }
    const att = getAttachment(req.user!.user_id, parsed.data.attachment_id);
    if (!att || att.kind !== 'image' || !fs.existsSync(att.path)) {
      res.status(404).json({ error: 'Image not found.' });
      return;
    }
    const dataUri = `data:${att.mime};base64,${fs.readFileSync(att.path).toString('base64')}`;
    const prompt = parsed.data.prompt || 'Analyze this image in detail and explain what it shows.';
    const text = await getAI().vision(prompt, [dataUri]);
    res.json({ text });
  }),
);

// --- Memory relevance (used for debugging / tools) ---
miscRouter.post(
  '/memory/retrieve',
  asyncHandler(async (req, res) => {
    const parsed = z.object({ query: z.string().min(1) }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'A query is required.' });
      return;
    }
    const user = getById(req.user!.user_id)!;
    if (!user.memory_enabled) {
      res.json({ memories: [] });
      return;
    }
    res.json({ memories: retrieveRelevant(parsed.data.query, listMemories(req.user!.user_id), 8) });
  }),
);
