import { Router } from 'express';
import { z } from 'zod';

import { requireAuth } from '../middleware/auth';
import { asyncHandler } from '../middleware/error';
import * as mem from '../memory/service';

export const memoriesRouter = Router();
memoriesRouter.use(requireAuth);

memoriesRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const q = typeof req.query.q === 'string' ? req.query.q : '';
    const cat = typeof req.query.category === 'string' ? req.query.category : undefined;
    const memories = q.trim()
      ? mem.searchMemories(req.user!.user_id, q)
      : mem.listMemories(req.user!.user_id, cat);
    res.json({ memories });
  }),
);

memoriesRouter.post(
  '/',
  asyncHandler(async (req, res) => {
    const parsed = z.object({
      category: z.enum(mem.MEMORY_CATEGORIES),
      content: z.string().min(1).max(1000),
      importance: z.number().int().min(1).max(5).optional(),
    }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join('; ') });
      return;
    }
    const m = mem.createMemory(req.user!.user_id, parsed.data);
    res.status(201).json({ memory: m });
  }),
);

memoriesRouter.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    const parsed = z.object({
      category: z.enum(mem.MEMORY_CATEGORIES).optional(),
      content: z.string().min(1).max(1000).optional(),
      importance: z.number().int().min(1).max(5).optional(),
    }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid input.' });
      return;
    }
    const m = mem.updateMemory(req.user!.user_id, req.params.id, parsed.data);
    if (!m) {
      res.status(404).json({ error: 'Memory not found.' });
      return;
    }
    res.json({ memory: m });
  }),
);

memoriesRouter.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const ok = mem.deleteMemory(req.user!.user_id, req.params.id);
    if (!ok) {
      res.status(404).json({ error: 'Memory not found.' });
      return;
    }
    res.json({ ok: true });
  }),
);

memoriesRouter.delete(
  '/',
  asyncHandler(async (req, res) => {
    const count = mem.deleteAllMemories(req.user!.user_id);
    res.json({ ok: true, deleted: count });
  }),
);
