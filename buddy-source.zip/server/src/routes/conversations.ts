import { Router } from 'express';
import { z } from 'zod';

import { requireAuth } from '../middleware/auth';
import { asyncHandler } from '../middleware/error';
import * as conv from '../services/conversations';

export const conversationsRouter = Router();
conversationsRouter.use(requireAuth);

conversationsRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const q = typeof req.query.q === 'string' ? req.query.q : '';
    const list = q.trim() ? conv.searchConversations(req.user!.user_id, q) : conv.listConversations(req.user!.user_id);
    res.json({ conversations: list });
  }),
);

conversationsRouter.post(
  '/',
  asyncHandler(async (req, res) => {
    const parsed = z.object({ title: z.string().max(200).optional() }).safeParse(req.body);
    const c = conv.createConversation(req.user!.user_id, parsed.success ? parsed.data.title : undefined);
    res.status(201).json({ conversation: c });
  }),
);

conversationsRouter.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const c = conv.getConversation(req.user!.user_id, req.params.id);
    if (!c) {
      res.status(404).json({ error: 'Conversation not found.' });
      return;
    }
    const messages = conv.getMessages(req.user!.user_id, req.params.id);
    res.json({ conversation: c, messages });
  }),
);

conversationsRouter.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    const parsed = z.object({ title: z.string().max(200) }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid title.' });
      return;
    }
    const c = conv.renameConversation(req.user!.user_id, req.params.id, parsed.data.title);
    if (!c) {
      res.status(404).json({ error: 'Conversation not found.' });
      return;
    }
    res.json({ conversation: c });
  }),
);

conversationsRouter.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const ok = conv.deleteConversation(req.user!.user_id, req.params.id);
    if (!ok) {
      res.status(404).json({ error: 'Conversation not found.' });
      return;
    }
    res.json({ ok: true });
  }),
);

// Edit a user message (rewrites content).
conversationsRouter.patch(
  '/:id/messages/:messageId',
  asyncHandler(async (req, res) => {
    const parsed = z.object({ content: z.string().max(8000) }).safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid content.' });
      return;
    }
    const msg = conv.updateMessage(req.user!.user_id, req.params.messageId, parsed.data.content, { role: 'user' });
    if (!msg) {
      res.status(404).json({ error: 'Message not found.' });
      return;
    }
    // Remove any following assistant reply so it can be regenerated.
    res.json({ message: msg });
  }),
);

conversationsRouter.delete(
  '/:id/messages/:messageId',
  asyncHandler(async (req, res) => {
    const ok = conv.deleteMessage(req.user!.user_id, req.params.messageId);
    if (!ok) {
      res.status(404).json({ error: 'Message not found.' });
      return;
    }
    res.json({ ok: true });
  }),
);
