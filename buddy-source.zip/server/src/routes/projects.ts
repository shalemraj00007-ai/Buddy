import { Router } from 'express';
import { z } from 'zod';

import { requireAuth } from '../middleware/auth';
import { asyncHandler } from '../middleware/error';
import * as projects from '../services/projects';
import { listTasks } from '../services/tasks';

export const projectsRouter = Router();
projectsRouter.use(requireAuth);

const projectSchema = z.object({
  name: z.string().min(1).max(200),
  description: z.string().max(2000).optional(),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
  status: z.enum(['active', 'paused', 'completed', 'archived']).optional(),
});

projectsRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    res.json({ projects: projects.listProjects(req.user!.user_id) });
  }),
);

projectsRouter.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const p = projects.getProject(req.user!.user_id, req.params.id);
    if (!p) {
      res.status(404).json({ error: 'Project not found.' });
      return;
    }
    const tasks = listTasks(req.user!.user_id, { project_id: req.params.id });
    res.json({ project: p, tasks });
  }),
);

projectsRouter.post(
  '/',
  asyncHandler(async (req, res) => {
    const parsed = projectSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues.map((i) => i.message).join('; ') });
      return;
    }
    const p = projects.createProject(req.user!.user_id, parsed.data);
    res.status(201).json({ project: p });
  }),
);

projectsRouter.patch(
  '/:id',
  asyncHandler(async (req, res) => {
    const parsed = projectSchema.partial().safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid input.' });
      return;
    }
    const p = projects.updateProject(req.user!.user_id, req.params.id, parsed.data);
    if (!p) {
      res.status(404).json({ error: 'Project not found.' });
      return;
    }
    res.json({ project: p });
  }),
);

projectsRouter.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const ok = projects.deleteProject(req.user!.user_id, req.params.id);
    if (!ok) {
      res.status(404).json({ error: 'Project not found.' });
      return;
    }
    res.json({ ok: true });
  }),
);
