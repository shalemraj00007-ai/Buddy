import { getDb } from '../db';
import { listReminders, updateReminder } from './reminders';
import { getById } from '../auth/service';

/**
 * Reminder scheduler.
 *
 * Periodically finds reminders that are due. In this build, "delivery" is
 * recorded (last_fired_at is set, recurring reminders advance to the next
 * occurrence). Actual push delivery is a platform integration point — in a
 * native app you'd hook local notifications here, and on web you'd use Web Push.
 * The hook is deliberately isolated so a real notifier can be added without
 * touching the rest of the app.
 */

let started = false;
let timer: NodeJS.Timeout | null = null;

/** Called for each due reminder. Replace with your push/notifier integration. */
function deliver(userId: string, reminder: any): void {
  const user = getById(userId);
  // Integration point: send a local/push notification here.
  const who = user ? user.name : 'user';
  console.log(`[notification] Reminder for ${who}: "${reminder.title}" at ${reminder.remind_at}`);
}

function nextOccurrence(r: any): string | null {
  if (!r.recurring) return null;
  const rule = r.recurring;
  const now = new Date();
  const at = rule.at ?? '09:00';
  const [h, m] = at.split(':').map((n: string) => Number(n));

  if (rule.type === 'daily') {
    const d = new Date(now);
    d.setHours(h || 0, m || 0, 0, 0);
    if (d.getTime() <= now.getTime()) d.setDate(d.getDate() + 1);
    return d.toISOString();
  }
  if (rule.type === 'weekly') {
    const days = rule.days ?? [1, 3, 5];
    for (let i = 1; i <= 7; i++) {
      const d = new Date(now);
      d.setDate(d.getDate() + i);
      if (days.includes(d.getDay())) {
        d.setHours(h || 0, m || 0, 0, 0);
        if (d.getTime() > now.getTime()) return d.toISOString();
      }
    }
    return null;
  }
  // monthly
  const d = new Date(now);
  d.setDate(d.getDate() + 1);
  d.setHours(h || 0, m || 0, 0, 0);
  return d.toISOString();
}

function tick(): void {
  const db = getDb();
  const now = new Date().toISOString();
  const reminders = listRemindersAll();
  for (const r of reminders) {
    if (!r.enabled || !r.remind_at) continue;
    if (r.remind_at <= now && r.remind_at !== r.last_fired_at) {
      deliver(r.user_id, r);
      const next = nextOccurrence(r);
      updateReminder(r.user_id, r.reminder_id, {
        last_fired_at: now,
        remind_at: next,
      });
    }
  }
  void db;
}

function listRemindersAll() {
  const db = getDb();
  return (db.prepare('SELECT * FROM reminders').all() as any[]).map((r) => ({
    ...r,
    enabled: !!r.enabled,
    recurring: r.recurring ? JSON.parse(r.recurring) : null,
  }));
}

export function startScheduler(intervalMs = 60_000): void {
  if (started) return;
  started = true;
  tick();
  timer = setInterval(tick, intervalMs);
  timer.unref?.();
}

export function stopScheduler(): void {
  if (timer) clearInterval(timer);
  started = false;
}
