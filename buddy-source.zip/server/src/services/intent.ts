/**
 * Deterministic natural-language intent parsing.
 *
 * Fast and reliable for the common assistant commands. This runs alongside the
 * model-based tool calling: if the model doesn't call a tool, we still catch
 * explicit requests ("remind me at 8pm", "add a task tomorrow") here.
 */

export type Intent =
  | { type: 'memory'; category: string; content: string }
  | { type: 'task'; action: 'create' | 'complete' | 'list'; title: string; due?: string | null; priority?: string }
  | { type: 'reminder'; action: 'create'; title: string; at?: string | null; recurring?: string }
  | { type: 'project'; action: 'create'; name: string }
  | { type: 'calc'; expression: string }
  | { type: 'time' }
  | { type: 'search'; query: string }
  | { type: 'none' };

const DAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

function strip(text: string, prefixes: string[]): { rest: string; matched: boolean } {
  const t = text.trim();
  for (const p of prefixes) {
    if (t.toLowerCase().startsWith(p)) {
      return { rest: t.slice(p.length).trim(), matched: true };
    }
  }
  return { rest: t, matched: false };
}

/** Parse relative/absolute due dates & times in a string. */
function parseWhen(text: string): { due: string | null; at?: string | null; recurring?: string; rest: string } {
  const lower = text.toLowerCase();

  const rec = /every\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday|day|morning|week)/.exec(lower);
  if (rec) {
    const word = rec[1];
    let recurring: string;
    if (word === 'day') recurring = 'daily';
    else if (word === 'week') recurring = 'weekly';
    else if (word === 'morning') recurring = 'daily';
    else recurring = 'weekly';
    return { due: null, recurring, rest: text.replace(rec[0], '').replace(/at\s+[0-9]{1,2}(:[0-9]{2})?\s*(am|pm)?/i, '').trim() };
  }

  let at: string | null = null;
  const timeMatch = /\bat\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/.exec(lower);
  if (timeMatch) {
    let h = Number(timeMatch[1]);
    const m = timeMatch[2] ? Number(timeMatch[2]) : 0;
    const ampm = timeMatch[3];
    if (ampm === 'pm' && h < 12) h += 12;
    if (ampm === 'am' && h === 12) h = 0;
    at = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }

  const base = new Date();
  const ymd = (d: Date) => {
    const yy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yy}-${mm}-${dd}`;
  };

  let due: string | null = null;
  let rest = text;
  if (/\btoday\b/.test(lower)) {
    due = ymd(base);
    rest = rest.replace(/\btoday\b/i, '');
  } else if (/\btomorrow\b/.test(lower)) {
    const d = new Date(base.getTime() + 864e5);
    due = ymd(d);
    rest = rest.replace(/\btomorrow\b/i, '');
  } else if (/in\s+(\d+)\s+days?/.test(lower)) {
    const n = Number(/in\s+(\d+)\s+days?/.exec(lower)![1]);
    due = ymd(new Date(base.getTime() + n * 864e5));
    rest = rest.replace(/in\s+\d+\s+days?/i, '');
  } else if (/day\s+after\s+tomorrow/.test(lower)) {
    due = ymd(new Date(base.getTime() + 2 * 864e5));
    rest = rest.replace(/day\s+after\s+tomorrow/i, '');
  } else {
    // absolute date like MM/DD or YYYY-MM-DD
    const abs = /(\d{4})-(\d{1,2})-(\d{1,2})/.exec(lower) || /(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?/.exec(lower);
    if (abs && abs[1].length === 4) {
      due = `${abs[1]}-${String(abs[2]).padStart(2, '0')}-${String(abs[3]).padStart(2, '0')}`;
      rest = rest.replace(/[^\s]+\s[^\s]+\s[^\s]+/, '');
    }
  }
  rest = rest.replace(/\bat\s+\d{1,2}(?::\d{2})?\s*(am|pm)?/i, '').replace(/\s{2,}/g, ' ').trim();
  return { due, at, rest };
}

export function parseIntent(userMessage: string): Intent {
  const text = userMessage.trim();
  const lower = text.toLowerCase();

  // --- memory ---
  let r = strip(text, ['remember', 'remember that', 'note that', 'note this', 'keep in mind', "don't forget"]);
  if (r.matched && r.rest.length > 5) {
    const category =
      /prefer|like|dislike|hate|love/.test(r.rest) ? 'Preference'
      : /want to|goal|aiming|trying to/.test(r.rest) ? 'Goal'
      : /(working on|building|creating)\b/.test(r.rest) ? 'Project'
      : 'Important fact';
    return { type: 'memory', category, content: r.rest.replace(/^(that|this)\s+/i, '') };
  }

  // --- reminder ---
  r = strip(text, ['remind me', 'set a reminder', 'set reminder', 'remind']);
  if (r.matched) {
    let title = r.rest.replace(/^(to|about|that)\s+/i, '');
    const parsed = parseWhen(title);
    title = parsed.rest;
    if (!title) title = 'Reminder';
    return { type: 'reminder', action: 'create', title, at: parsed.at, recurring: parsed.recurring };
  }

  // --- project ---
  r = strip(text, ['create a project called', 'create project', 'start a project called', 'make a project called', 'create a project named']);
  if (r.matched) {
    return { type: 'project', action: 'create', name: r.rest };
  }

  // --- task complete ---
  r = strip(text, ['mark as done', 'mark done', 'mark complete', 'complete task', 'finish task', 'mark as completed']);
  if (r.matched && r.rest.length > 2) {
    return { type: 'task', action: 'complete', title: r.rest.replace(/^(the|task)\s+/i, '') };
  }

  // --- task create ---
  r = strip(text, ['add a task to', 'add task', 'create a task to', 'create task', 'add a task', 'add todo', 'schedule task']);
  if (r.matched) {
    let body = r.rest;
    const parsed = parseWhen(body);
    body = parsed.rest;
    const priority = /urgent|asap|high priority/.test(lower) ? 'high'
      : /low priority/.test(lower) ? 'low' : 'medium';
    return { type: 'task', action: 'create', title: body || 'Untitled task', due: parsed.due, priority };
  }

  // --- list tasks ---
  if (/(what are my tasks|list my tasks|show tasks|my to-?do|list tasks)/.test(lower)) {
    return { type: 'task', action: 'list', title: '' };
  }

  // --- time ---
  if (/(what time is it|current time|tell me the time)/.test(lower)) {
    return { type: 'time' };
  }

  // --- calc ---
  const calcMatch = /(?:calculate|compute|what is|what's)\s+([0-9+\-*/().\s^%]+)/i.exec(lower);
  if (calcMatch && /[0-9]/.test(calcMatch[1])) {
    return { type: 'calc', expression: calcMatch[1] };
  }

  // --- search ---
  r = strip(text, ['search the web for', 'search for', 'search the internet for', 'look up']);
  if (r.matched && r.rest.length > 2) {
    return { type: 'search', query: r.rest };
  }

  return { type: 'none' };
}
