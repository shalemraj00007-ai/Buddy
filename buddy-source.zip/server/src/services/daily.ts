import { getById } from '../auth/service';
import { listTasks, tasksOverview } from './tasks';
import { listProjects } from './projects';
import { listReminders } from './reminders';
import { listMemories } from '../memory/service';

export interface DailyData {
  greeting: string;
  date: string;
  priorities: {
    title: string;
    due_date: string | null;
    project_name: string | null;
  }[];
  reminders: { reminder_id: string; title: string; remind_at: string | null }[];
  goals: string[];
  projects: { name: string; progress: number; status: string; color: string }[];
  suggestion: string;
  stats: { tasks: { todo: number; in_progress: number; completed: number } };
}

export function getDaily(userId: string): DailyData {
  const user = getById(userId);
  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  const overview = tasksOverview(userId);
  // Today's priorities: due today first, then high priority open tasks.
  const today = now.toISOString().slice(0, 10);
  const openTasks = listTasks(userId, { status: 'todo' });
  const inProgress = listTasks(userId, { status: 'in_progress' });
  const fmt = (t: any) => ({ title: t.title, due_date: t.due_date, project_name: t.project_name ?? null });
  let priorities = [
    ...inProgress.map(fmt),
    ...openTasks.filter((t) => t.due_date === today).map(fmt),
    ...openTasks.filter((t) => t.due_date !== today && t.priority === 'high').map(fmt),
  ];
  // Fall back to any open tasks so the dashboard always feels helpful.
  if (priorities.length === 0) priorities = openTasks.map(fmt);
  priorities = priorities.slice(0, 6);

  const reminders = listReminders(userId, true)
    .filter((r) => r.remind_at && new Date(r.remind_at).getTime() >= now.getTime())
    .slice(0, 5)
    .map((r) => ({ reminder_id: r.reminder_id, title: r.title, remind_at: r.remind_at }));

  const goals = listMemories(userId, 'Goal').slice(0, 5).map((m) => m.content);
  const projects = listProjects(userId).map((p) => ({
    name: p.name,
    progress: p.progress ?? 0,
    status: p.status,
    color: p.color,
  }));

  // Personalized suggestion built from real data.
  let suggestion = 'Keep up the good work — a focused block of 25 minutes on a task is a great start.';
  if (overview.dueToday > 0) {
    suggestion = `You have ${overview.dueToday} task(s) due today. I'd start with the earliest one to get ahead.`;
  } else if (openTasks.length) {
    suggestion = `You have ${openTasks.length} open task(s). Want to tackle the highest-priority one now?`;
  } else if (projects.length) {
    suggestion = `No tasks due today — consider making progress on "${projects[0].name}".`;
  }

  return {
    greeting: user ? `${greeting}, ${user.name.split(' ')[0]}` : greeting,
    date: now.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
    priorities,
    reminders,
    goals,
    projects,
    suggestion,
    stats: { tasks: overview.byStatus },
  };
}
