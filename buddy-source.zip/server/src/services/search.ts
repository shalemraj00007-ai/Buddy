import { config } from '../config';

export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

export interface SearchProvider {
  id: string;
  isConfigured(): boolean;
  search(query: string): Promise<SearchResult[]>;
}

/** Tavily search — plug your SEARCH_API_KEY + SEARCH_PROVIDER=tavily in .env. */
class TavilyProvider implements SearchProvider {
  id = 'tavily';
  isConfigured() {
    return !!config.search.apiKey;
  }
  async search(query: string): Promise<SearchResult[]> {
    const res = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: config.search.apiKey, query, max_results: 6 }),
    });
    if (!res.ok) throw new Error(`Search provider responded ${res.status}.`);
    const data = (await res.json()) as { results?: { title?: string; url?: string; content?: string }[] };
    return (data.results ?? []).map((r) => ({
      title: r.title ?? 'Untitled',
      url: r.url ?? '',
      snippet: r.content ?? '',
    }));
  }
}

/** No provider configured — honest integration point. */
class NoneProvider implements SearchProvider {
  id = 'none';
  isConfigured() {
    return false;
  }
  async search(_query: string): Promise<SearchResult[]> {
    throw new Error(
      'Web search is not configured. Set SEARCH_PROVIDER and SEARCH_API_KEY in the server .env.',
    );
  }
}

const providers: Record<string, SearchProvider> = {
  tavily: new TavilyProvider(),
  none: new NoneProvider(),
};

function getProvider(): SearchProvider {
  return providers[config.search.provider] ?? providers.none;
}

export async function searchWeb(query: string): Promise<SearchResult[]> {
  return getProvider().search(query);
}

export function searchConfigured(): boolean {
  return getProvider().isConfigured();
}
