import fs from 'node:fs';
import path from 'node:path';
import { Readable } from 'node:stream';

import mammoth from 'mammoth';
import multer from 'multer';

import { getDb } from '../db';
import { config } from '../config';
import { nowIso, uid } from '../lib/ids';

export interface Attachment {
  attachment_id: string;
  user_id: string;
  message_id: string | null;
  kind: 'image' | 'document';
  filename: string;
  mime: string;
  path: string;
  size: number;
  text_content: string | null;
  created_at: string;
}

export const TEXT_EXTENSIONS = new Set(['.txt', '.md', '.markdown', '.csv', '.json', '.log']);
export const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp']);
export const DOC_EXTENSIONS = new Set(['.pdf', '.docx']);

export const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: config.limits.maxUploadBytes, files: 8 },
});

export function detectKind(filename: string): 'image' | 'document' | null {
  const ext = path.extname(filename).toLowerCase();
  if (IMAGE_EXTENSIONS.has(ext)) return 'image';
  if (TEXT_EXTENSIONS.has(ext) || DOC_EXTENSIONS.has(ext)) return 'document';
  return null;
}

export async function extractText(filename: string, mime: string, buffer: Buffer): Promise<string> {
  const ext = path.extname(filename).toLowerCase();

  if (TEXT_EXTENSIONS.has(ext)) {
    // Guard against very large files
    if (buffer.byteLength > config.limits.maxTextExtractBytes) {
      return buffer.subarray(0, config.limits.maxTextExtractBytes).toString('utf-8');
    }
    return buffer.toString('utf-8');
  }

  if (ext === '.pdf') {
    const pdfParse = (await import('pdf-parse')).default;
    const data = await pdfParse(buffer, { max: 60 });
    return data.text || '';
  }

  if (ext === '.docx') {
    const result = await mammoth.extractRawText({ buffer });
    return result.value || '';
  }

  return '';
}

export function chunkText(text: string, size = 2000, overlap = 200): string[] {
  const chunks: string[] = [];
  if (text.length <= size) return text ? [text] : [];
  let i = 0;
  while (i < text.length) {
    chunks.push(text.slice(i, i + size));
    i += size - overlap;
  }
  return chunks;
}

/** Save a file, extract text, and create an attachment row. Returns attachment or throws. */
export async function storeAttachment(
  userId: string,
  file: Express.Multer.File,
): Promise<Attachment> {
  const kind = detectKind(file.originalname);
  if (!kind) {
    throw new Error(`Unsupported file type: ${file.originalname}`);
  }
  const id = uid();
  const safeName = `${id}_${path.basename(file.originalname).replace(/[^a-zA-Z0-9._-]/g, '_')}`;
  const dest = path.join(config.uploadsDir, safeName);
  fs.writeFileSync(dest, file.buffer);

  let textContent: string | null = null;
  try {
    const text = await extractText(file.originalname, file.mimetype, file.buffer);
    textContent = text.slice(0, config.limits.maxTextExtractBytes);
  } catch (e) {
    textContent = `[Could not extract text: ${e instanceof Error ? e.message : 'unknown'}]`;
  }

  const row: Attachment = {
    attachment_id: id,
    user_id: userId,
    message_id: null,
    kind,
    filename: file.originalname,
    mime: file.mimetype,
    path: dest,
    size: file.size,
    text_content: textContent,
    created_at: nowIso(),
  };
  getDb()
    .prepare(
      `INSERT INTO attachments (attachment_id,user_id,message_id,kind,filename,mime,path,size,text_content,created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
    )
    .run(
      id,
      userId,
      null,
      kind,
      file.originalname,
      file.mimetype,
      dest,
      file.size,
      textContent,
      row.created_at,
    );
  return row;
}

export function linkAttachments(userId: string, messageId: string, attachmentIds: string[]): void {
  const db = getDb();
  for (const id of attachmentIds) {
    db.prepare('UPDATE attachments SET message_id = ? WHERE attachment_id = ? AND user_id = ?').run(
      messageId,
      id,
      userId,
    );
  }
}

export function getAttachment(userId: string, attachmentId: string): Attachment | null {
  const row = getDb()
    .prepare('SELECT * FROM attachments WHERE user_id = ? AND attachment_id = ?')
    .get(userId, attachmentId);
  return row ? (row as Attachment) : null;
}

export function deleteAttachment(userId: string, attachmentId: string): boolean {
  const att = getAttachment(userId, attachmentId);
  if (!att) return false;
  try {
    fs.unlinkSync(att.path);
  } catch {
    // ignore missing file
  }
  const info = getDb()
    .prepare('DELETE FROM attachments WHERE user_id = ? AND attachment_id = ?')
    .run(userId, attachmentId);
  return info.changes > 0;
}

export function dataUriToBuffer(dataUri: string): Buffer {
  const comma = dataUri.indexOf(',');
  const b64 = dataUri.slice(comma + 1);
  return Buffer.from(b64, 'base64');
}

// multer expects req.file; keep a helper for tests to read a buffer
export function bufferToStream(buf: Buffer): Readable {
  return Readable.from(buf);
}
