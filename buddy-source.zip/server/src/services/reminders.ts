import { getDb } from '../db';
import { nowIso, uid } from '../lib/ids';

export interface RecurringRule {
  type: 'daily' | 'weekly' | 'monthly';
  at?: string; // "HH:MM" local
  days?: number[]; // 0..6 for weekly (0 = Sunday)
}

export interface Reminder {
  reminder_id: string;
  user_id: string;
  title: string;
  note: string;
  remind_at: string | null;
  recurring: RecurringRule | null;
  enabled: boolean;
  created_at: string;
  updated_at: string;
  last_fired_at: string | null;
}

export function createReminder(
  userId: string,
  input: { title: string; note?: string; remind_at?: string | null; recurring?: RecurringRule | null },
): Reminder {
  const db = getDb();
  const now = nowIso();
  const id = uid();
  db.prepare(
    `INSERT INTO reminders (reminder_id,user_id,title,note,remind_at,recurring,enabled,created_at,updated_at)
     VALUES (?,?,?,?,?,?,?,?,?)`,
  ).run(
    id,
    userId,
    input.title,
    input.note ?? '',
    input.remind_at ?? null,
    input.recurring ? JSON.stringify(input.recurring) : null,
    1,
    now,
    now,
  );
  return getReminder(userId, id)!;
}

export function getReminder(userId: string, reminderId: string): Reminder | null {
  const row = getDb()
    .prepare('SELECT * FROM reminders WHERE user_id = ? AND reminder_id = ?')
    .get(userId, reminderId);
  return row ? toReminder(row) : null;
}

export function toReminder(row: any): Reminder {
  return {
    ...row,
    enabled: !!row.enabled,
    recurring: row.recurring ? JSON.parse(row.recurring) : null,
  };
}

export function listReminders(userId: string, enabledOnly = false): Reminder[] {
  const db = getDb();
  const where = enabledOnly ? 'WHERE user_id = ? AND enabled = 1' : 'WHERE user_id = ?';
  return (db
    .prepare(`SELECT * FROM reminders ${where} ORDER BY remind_at ASC`)
    .all(userId) as any[]).map(toReminder);
}

export function updateReminder(
  userId: string,
  reminderId: string,
  fields: Partial<{
    title: string;
    note: string;
    remind_at: string | null;
    recurring: RecurringRule | null;
    enabled: boolean;
    last_fired_at: string | null;
  }>,
): Reminder | null {
  const db = getDb();
  const sets: string[] = ['updated_at = ?'];
  const vals: unknown[] = [nowIso()];
  if (fields.title !== undefined) {
    sets.push('title = ?');
    vals.push(fields.title);
  }
  if (fields.note !== undefined) {
    sets.push('note = ?');
    vals.push(fields.note);
  }
  if (fields.remind_at !== undefined) {
    sets.push('remind_at = ?');
    vals.push(fields.remind_at || null);
  }
  if (fields.last_fired_at !== undefined) {
    sets.push('last_fired_at = ?');
    vals.push(fields.last_fired_at);
  }
  if (fields.recurring !== undefined) {
    sets.push('recurring = ?');
    vals.push(fields.recurring ? JSON.stringify(fields.recurring) : null);
  }
  if (fields.enabled !== undefined) {
    sets.push('enabled = ?');
    vals.push(fields.enabled ? 1 : 0);
  }
  vals.push(userId, reminderId);
  db.prepare(`UPDATE reminders SET ${sets.join(', ')} WHERE user_id = ? AND reminder_id = ?`).run(...vals);
  return getReminder(userId, reminderId);
}

export function deleteReminder(userId: string, reminderId: string): boolean {
  const info = getDb()
    .prepare('DELETE FROM reminders WHERE user_id = ? AND reminder_id = ?')
    .run(userId, reminderId);
  return info.changes > 0;
}

export function upcomingReminders(userId: string, withinMs: number): Reminder[] {
  const db = getDb();
  const now = Date.now();
  const horizon = now + withinMs;
  const rows = db
    .prepare('SELECT * FROM reminders WHERE user_id = ? AND enabled = 1 AND remind_at IS NOT NULL')
    .all(userId) as any[];
  return rows
    .map(toReminder)
    .filter((r) => {
      if (!r.remind_at) return false;
      const t = new Date(r.remind_at).getTime();
      return t >= now && t <= horizon;
    })
    .sort((a, b) => (a.remind_at! < b.remind_at! ? -1 : 1));
}
