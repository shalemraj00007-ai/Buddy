import { getAI } from '../ai';
import type { AIMessage } from '../ai/types';
import fs from 'node:fs';
import { getDb } from '../db';
import { getById } from '../auth/service';
import { memoryEnabled, createMemory, retrieveRelevant, listMemories } from '../memory/service';
import { extractMemories } from '../memory/extract';
import { listTasks } from './tasks';
import { listProjects } from './projects';
import { upcomingReminders } from './reminders';
import { getAttachment } from './files';
import { parseIntent } from './intent';
import { runTool } from '../tools';
import { toolNames } from '../tools';
import * as conv from './conversations';
import { nowIso } from '../lib/ids';

export interface StreamSink {
  meta: (m: { conversation_id: string; message_id: string; model?: string }) => void;
  delta: (text: string) => void;
  done: (info: { text: string; toolText?: string }) => void;
  error: (message: string) => void;
}

export interface ChatRequest {
  conversationId?: string;
  content: string;
  attachmentIds?: string[];
  regenerateMessageId?: string;
}

const MAX_CONTEXT_MESSAGES = 16;

function personalityText(personality: string): string {
  switch (personality) {
    case 'concise': return 'Prefer short, direct answers with minimal fluff.';
    case 'detailed': return 'Give thorough, well-structured, in-depth answers.';
    case 'technical': return 'Be precise and technical; use correct jargon and specifics.';
    case 'casual': return 'Be warm, relaxed and conversational; light touch of humor.';
    default: return 'Be friendly, calm, helpful, honest and adaptable. Adjust style to the situation.';
  }
}

function buildSystemPrompt(user: any, context: string): string {
  return [
    `You are Buddy, a personal AI assistant for ${user.name || 'the user'}.`,
    `Personality: ${personalityText(user.ai_personality)}`,
    '',
    `Language: respond in ${user.language === 'en' ? 'English' : user.language || 'English'}.`,
    '',
    'Guidelines:',
    '- Be genuinely helpful, calm and natural. Do not be overly enthusiastic or robotic.',
    '- Do not claim to be conscious, have emotions, or be a therapist. Never diagnose health/mental-health conditions.',
    '- Acknowledge emotional signals briefly when relevant (e.g. frustration, excitement) and move on — don\'t overdo it.',
    '- For programming be technical and precise; for study be simple and educational; for planning be organized and practical; for casual chat be natural.',
    '- If you used any tool (task, reminder, memory, etc.), briefly confirm what you did.',
    '- Be honest about your limits.',
    '',
    '--- Relevant user context (retrieved just now) ---',
    context || '(No relevant stored context.)',
    '',
    'Remember: this context is private to the user. Do not reveal or fabricate unrelated personal data.',
  ].join('\n');
}

function buildContext(userId: string, query: string): string {
  const db = getDb();
  const parts: string[] = [];
  if (memoryEnabled(userId)) {
    const memories = retrieveRelevant(query, listMemories(userId), 5);
    if (memories.length) {
      parts.push(
        'Memories:\n' + memories.map((m) => `- [${m.category}] ${m.content}`).join('\n'),
      );
    }
  }
  const tasks = listTasks(userId, { status: 'todo' }).slice(0, 6);
  if (tasks.length) {
    parts.push('Open tasks:\n' + tasks.map((t) => `- ${t.title}${t.due_date ? ` (due ${t.due_date})` : ''}`).join('\n'));
  }
  const projects = listProjects(userId).slice(0, 6);
  if (projects.length) {
    parts.push('Projects:\n' + projects.map((p) => `- ${p.name} (${p.status})`).join('\n'));
  }
  const reminders = upcomingReminders(userId, 48 * 3600 * 1000).slice(0, 4);
  if (reminders.length) {
    parts.push('Upcoming reminders:\n' + reminders.map((r) => `- ${r.title} at ${r.remind_at}`).join('\n'));
  }
  return parts.join('\n\n');
}

/**
 * Handle deterministic tool intents (fast, reliable assistant commands).
 * Returns a natural confirmation string, or null if the message isn't an
 * explicit command we handle deterministically.
 */
async function runDeterministicIntent(
  userId: string,
  userName: string,
  content: string,
): Promise<string | null> {
  const intent = parseIntent(content);
  switch (intent.type) {
    case 'memory': {
      if (!memoryEnabled(userId)) return "Memory is currently disabled, so I won't save that. You can enable it in Settings.";
      createMemory(userId, { category: intent.category as any, content: intent.content, source_conversation_id: null });
      return `Got it — I'll remember that as a ${intent.category.toLowerCase()}.`;
    }
    case 'task': {
      const res = await runTool('tasks', { userId, userName }, {
        action: intent.action,
        title: intent.title,
        due_date: intent.due ?? undefined,
        priority: intent.priority,
      });
      return res.text;
    }
    case 'reminder': {
      const res = await runTool('reminders', { userId, userName }, {
        title: intent.title,
        at: intent.recurring ? null : intent.at ?? null,
      });
      return res.text;
    }
    case 'project': {
      const res = await runTool('projects', { userId, userName }, { name: intent.name });
      return res.text;
    }
    case 'calc': {
      const res = await runTool('calculator', { userId, userName }, { expression: intent.expression });
      return res.text;
    }
    case 'time': {
      return `It's ${new Date().toLocaleString()}.`;
    }
    case 'search': {
      const res = await runTool('web_search', { userId, userName }, { query: intent.query });
      return res.text;
    }
    case 'none':
      return null;
  }
}

export async function runChat(
  userId: string,
  req: ChatRequest,
  sink: StreamSink,
): Promise<void> {
  const user = getById(userId)!;
  const content = req.content.trim();
  if (!content && (!req.attachmentIds || !req.attachmentIds.length)) {
    sink.error('Please enter a message.');
    return;
  }

  const db = getDb();

  // Ensure a conversation exists.
  let conversationId = req.conversationId;
  if (!conversationId) {
    const c = conv.createConversation(userId, content.slice(0, 40));
    conversationId = c.conversation_id;
  } else if (!conv.getConversation(userId, conversationId)) {
    sink.error('Conversation not found.');
    return;
  }

  // Load attachments.
  const attachments = (req.attachmentIds ?? [])
    .map((id) => getAttachment(userId, id))
    .filter(Boolean) as any[];

  // Save the user message.
  let userMessage;
  let regenerating = false;
  if (req.regenerateMessageId) {
    // Replace the last assistant message in this conversation.
    const history = conv.getMessages(userId, conversationId);
    const idx = history.findIndex((m) => m.message_id === req.regenerateMessageId);
    if (idx >= 0 && history[idx + 1]?.role === 'assistant') {
      conv.deleteMessage(userId, history[idx + 1].message_id);
    }
    regenerating = true;
  }
  if (!regenerating) {
    userMessage = conv.addMessage(userId, conversationId, 'user', content);
  }

  sink.meta({ conversation_id: conversationId, message_id: 'pending' });

  // --- 1. Deterministic tool intent ---
  const toolReply = await runDeterministicIntent(userId, user.name, content);
  if (toolReply) {
    conv.addMessage(userId, conversationId, 'assistant', toolReply);
    sink.done({ text: toolReply, toolText: toolReply });
    // Explicit tool commands already store what they need (e.g. "remember X"
    // saved a memory); skip auto-extraction to avoid duplicates.
    return;
  }

  // --- 2. Build AI context and stream ---
  const context = buildContext(userId, content);
  const history = conv.getMessages(userId, conversationId).slice(-MAX_CONTEXT_MESSAGES);

  const aiMessages: AIMessage[] = [
    { role: 'system', content: buildSystemPrompt(user, context) },
    ...history.map((m) => {
      if (m.role !== 'assistant' && m.role !== 'user') return null;
      return {
        role: m.role as 'user' | 'assistant',
        content: m.content || '(no content)',
      } as AIMessage;
    }).filter(Boolean) as AIMessage[],
  ];

  // Attach images / documents to the last user message if present.
  if (attachments.length) {
    const lastUser = [...aiMessages].reverse().find((m) => m.role === 'user');
    if (lastUser) {
      const parts: any[] = [];
      if (typeof lastUser.content === 'string') parts.push({ type: 'text', text: lastUser.content });
      for (const att of attachments) {
        if (att.kind === 'image') {
          parts.push({ type: 'image_url', image_url: `data:${att.mime};base64,${fs.readFileSync(att.path).toString('base64')}` });
        } else if (att.kind === 'document' && att.text_content) {
          parts.push({ type: 'text', text: `\n[Attached document "${att.filename}"]:\n${att.text_content.slice(0, 8000)}` });
        }
      }
      lastUser.content = parts;
    }
  }

  const ai = getAI();
  let fullText = '';
  let doneErr: Error | null = null;
  try {
    const result = await ai.chat(aiMessages, {}, (delta) => {
      fullText += delta;
      sink.delta(delta);
    });
    // Handle any model tool calls (for providers that support them).
    if (result.toolCalls.length) {
      const toolTexts: string[] = [];
      for (const tc of result.toolCalls) {
        if (toolNames().includes(tc.name)) {
          const tr = await runTool(tc.name, { userId, userName: user.name }, tc.arguments);
          toolTexts.push(tr.text);
        }
      }
      if (toolTexts.length && fullText.trim()) {
        fullText += '\n\n' + toolTexts.join('\n');
      } else if (toolTexts.length && !fullText.trim()) {
        fullText = toolTexts.join('\n');
      }
    }
  } catch (e) {
    doneErr = e instanceof Error ? e : new Error(String(e));
    if (!fullText) {
      const friendly = friendlyError(doneErr, ai.id);
      conv.addMessage(userId, conversationId, 'assistant', '', { error: friendly });
      sink.error(friendly);
      return;
    }
  }

  if (!fullText.trim()) {
    const friendly = friendlyError(doneErr ?? new Error('Empty reply.'), ai.id);
    conv.addMessage(userId, conversationId, 'assistant', '', { error: friendly });
    sink.error(friendly);
    return;
  }

  const assistantMsg = conv.addMessage(userId, conversationId, 'assistant', fullText);
  sink.meta({ conversation_id: conversationId, message_id: assistantMsg.message_id });
  sink.done({ text: fullText });

  await maybeExtractMemory(userId, conversationId, content);
}

async function maybeExtractMemory(userId: string, conversationId: string, content: string): Promise<void> {
  if (!memoryEnabled(userId)) return;
  try {
    const candidates = extractMemories(content);
    for (const c of candidates) {
      // De-duplicate roughly.
      const existing = listMemories(userId);
      const dup = existing.some((m) => m.content.toLowerCase().includes(c.content.slice(0, 20).toLowerCase()));
      if (!dup) createMemory(userId, { ...c, source_conversation_id: conversationId });
    }
  } catch {
    // never let memory extraction break the chat
  }
}

function friendlyError(e: Error, providerId: string): string {
  const msg = e.message || 'Unknown error';
  if (providerId === 'ollama') {
    return `I couldn't reach your local model (${msg}). Make sure Ollama is running and the model is pulled.`;
  }
  if (providerId === 'openai') {
    return `The AI service had a problem (${msg}). Check the server configuration.`;
  }
  return `Something went wrong generating a reply: ${msg}`;
}
