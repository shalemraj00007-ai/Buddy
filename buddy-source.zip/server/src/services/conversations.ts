import { getDb } from '../db';
import { nowIso, uid } from '../lib/ids';

export interface Conversation {
  conversation_id: string;
  user_id: string;
  title: string;
  archived: boolean;
  created_at: string;
  updated_at: string;
}

export interface Message {
  message_id: string;
  conversation_id: string;
  user_id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  error: string | null;
  model: string | null;
  timestamp: string;
}

export interface MessageWithAttachments extends Message {
  attachments: any[];
}

export function createConversation(userId: string, title = 'New chat'): Conversation {
  const db = getDb();
  const now = nowIso();
  const id = uid();
  db.prepare(
    `INSERT INTO conversations (conversation_id,user_id,title,archived,created_at,updated_at)
     VALUES (?,?,?,0,?,?)`,
  ).run(id, userId, title, now, now);
  return getConversation(userId, id)!;
}

export function getConversation(userId: string, conversationId: string): Conversation | null {
  const row = getDb()
    .prepare('SELECT * FROM conversations WHERE user_id = ? AND conversation_id = ?')
    .get(userId, conversationId);
  return row ? toConversation(row) : null;
}

function toConversation(row: any): Conversation {
  return { ...row, archived: !!row.archived };
}

export function listConversations(userId: string): Conversation[] {
  const db = getDb();
  return (db
    .prepare(
      `SELECT * FROM conversations WHERE user_id = ? AND archived = 0 ORDER BY updated_at DESC`,
    )
    .all(userId) as any[]).map(toConversation);
}

export function searchConversations(userId: string, query: string): Conversation[] {
  const db = getDb();
  const like = `%${query}%`;
  return (db
    .prepare(
      `SELECT DISTINCT c.* FROM conversations c
       LEFT JOIN messages m ON m.conversation_id = c.conversation_id
       WHERE c.user_id = ? AND c.archived = 0
         AND (c.title LIKE ? OR m.content LIKE ?)
       ORDER BY c.updated_at DESC LIMIT 30`,
    )
    .all(userId, like, like) as any[]).map(toConversation);
}

export function renameConversation(userId: string, conversationId: string, title: string): Conversation | null {
  const db = getDb();
  db.prepare(
    'UPDATE conversations SET title = ?, updated_at = ? WHERE user_id = ? AND conversation_id = ?',
  ).run(title, nowIso(), userId, conversationId);
  return getConversation(userId, conversationId);
}

export function touchConversation(userId: string, conversationId: string): void {
  getDb()
    .prepare('UPDATE conversations SET updated_at = ? WHERE user_id = ? AND conversation_id = ?')
    .run(nowIso(), userId, conversationId);
}

export function deleteConversation(userId: string, conversationId: string): boolean {
  const info = getDb()
    .prepare('DELETE FROM conversations WHERE user_id = ? AND conversation_id = ?')
    .run(userId, conversationId);
  return info.changes > 0;
}

export function addMessage(
  userId: string,
  conversationId: string,
  role: 'user' | 'assistant' | 'system',
  content: string,
  opts: { error?: string | null; model?: string | null } = {},
): Message {
  const db = getDb();
  const id = uid();
  const now = nowIso();
  db.prepare(
    `INSERT INTO messages (message_id,conversation_id,user_id,role,content,error,model,timestamp)
     VALUES (?,?,?,?,?,?,?,?)`,
  ).run(id, conversationId, userId, role, content, opts.error ?? null, opts.model ?? null, now);
  touchConversation(userId, conversationId);
  return {
    message_id: id,
    conversation_id: conversationId,
    user_id: userId,
    role,
    content,
    error: opts.error ?? null,
    model: opts.model ?? null,
    timestamp: now,
  };
}

export function getMessages(userId: string, conversationId: string): MessageWithAttachments[] {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT m.* FROM messages m
       WHERE m.user_id = ? AND m.conversation_id = ?
       ORDER BY m.timestamp ASC, m.rowid ASC`,
    )
    .all(userId, conversationId) as Message[];
  return rows.map((m) => ({
    ...m,
    attachments: db
      .prepare('SELECT * FROM attachments WHERE message_id = ?')
      .all(m.message_id),
  }));
}

export function getLastMessages(userId: string, conversationId: string, limit = 20): Message[] {
  const db = getDb();
  return db
    .prepare(
      `SELECT * FROM messages WHERE user_id = ? AND conversation_id = ?
       ORDER BY timestamp DESC LIMIT ?`,
    )
    .all(userId, conversationId, limit) as Message[];
}

export function updateMessage(
  userId: string,
  messageId: string,
  content: string,
  opts: { role?: 'user' | 'assistant'; error?: string | null } = {},
): Message | null {
  const db = getDb();
  db.prepare(
    `UPDATE messages SET content = ?, error = ?, role = COALESCE(?, role) WHERE user_id = ? AND message_id = ?`,
  ).run(content, opts.error ?? null, opts.role ?? null, userId, messageId);
  const row = db.prepare('SELECT * FROM messages WHERE user_id = ? AND message_id = ?').get(userId, messageId);
  return row ? (row as Message) : null;
}

export function deleteMessage(userId: string, messageId: string): boolean {
  const info = getDb()
    .prepare('DELETE FROM messages WHERE user_id = ? AND message_id = ?')
    .run(userId, messageId);
  return info.changes > 0;
}
