import { getDb } from '../db';
import { nowIso, uid } from '../lib/ids';

export type TaskStatus = 'todo' | 'in_progress' | 'completed';
export type TaskPriority = 'low' | 'medium' | 'high';

export interface Task {
  task_id: string;
  user_id: string;
  project_id: string | null;
  title: string;
  description: string;
  priority: TaskPriority;
  due_date: string | null;
  status: TaskStatus;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  project_name?: string | null;
}

export interface TaskFilters {
  status?: TaskStatus;
  priority?: TaskPriority;
  project_id?: string;
  search?: string;
  sort?: 'created_at' | 'due_date' | 'priority' | 'title';
  direction?: 'asc' | 'desc';
}

export function createTask(
  userId: string,
  input: {
    title: string;
    description?: string;
    priority?: TaskPriority;
    due_date?: string | null;
    status?: TaskStatus;
    project_id?: string | null;
  },
): Task {
  const db = getDb();
  const now = nowIso();
  const id = uid();
  db.prepare(
    `INSERT INTO tasks (task_id,user_id,project_id,title,description,priority,due_date,status,created_at,updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
  ).run(
    id,
    userId,
    input.project_id ?? null,
    input.title,
    input.description ?? '',
    input.priority ?? 'medium',
    input.due_date ?? null,
    input.status ?? 'todo',
    now,
    now,
  );
  return getTask(userId, id)!;
}

export function getTask(userId: string, taskId: string): Task | null {
  const row = getDb()
    .prepare(
      `SELECT t.*, p.name AS project_name FROM tasks t
       LEFT JOIN projects p ON p.project_id = t.project_id
       WHERE t.user_id = ? AND t.task_id = ?`,
    )
    .get(userId, taskId);
  return row ? (row as Task) : null;
}

export function listTasks(userId: string, f: TaskFilters = {}): Task[] {
  const db = getDb();
  const where = ['t.user_id = ?'];
  const vals: unknown[] = [userId];
  if (f.status) {
    where.push('t.status = ?');
    vals.push(f.status);
  }
  if (f.priority) {
    where.push('t.priority = ?');
    vals.push(f.priority);
  }
  if (f.project_id) {
    where.push('t.project_id = ?');
    vals.push(f.project_id);
  }
  if (f.search) {
    where.push('(t.title LIKE ? OR t.description LIKE ?)');
    const like = `%${f.search}%`;
    vals.push(like, like);
  }
  const orderMap: Record<string, string> = {
    created_at: 't.created_at',
    due_date: 't.due_date',
    priority: "CASE t.priority WHEN 'high' THEN 0 WHEN 'medium' THEN 1 ELSE 2 END",
    title: 't.title',
  };
  const order = orderMap[f.sort ?? 'created_at'] ?? orderMap.created_at;
  const dir = f.direction === 'asc' ? 'ASC' : 'DESC';
  return db
    .prepare(
      `SELECT t.*, p.name AS project_name FROM tasks t
       LEFT JOIN projects p ON p.project_id = t.project_id
       WHERE ${where.join(' AND ')} ORDER BY ${order} ${dir}, t.created_at DESC`,
    )
    .all(...vals) as Task[];
}

export function updateTask(
  userId: string,
  taskId: string,
  fields: Partial<{
    title: string;
    description: string;
    priority: TaskPriority;
    due_date: string | null;
    status: TaskStatus;
    project_id: string | null;
  }>,
): Task | null {
  const db = getDb();
  const sets: string[] = ['updated_at = ?'];
  const vals: unknown[] = [nowIso()];
  if (fields.title !== undefined) {
    sets.push('title = ?');
    vals.push(fields.title);
  }
  if (fields.description !== undefined) {
    sets.push('description = ?');
    vals.push(fields.description);
  }
  if (fields.priority !== undefined) {
    sets.push('priority = ?');
    vals.push(fields.priority);
  }
  if (fields.due_date !== undefined) {
    sets.push('due_date = ?');
    vals.push(fields.due_date || null);
  }
  if (fields.status !== undefined) {
    sets.push('status = ?', 'completed_at = ?');
    vals.push(fields.status, fields.status === 'completed' ? nowIso() : null);
  }
  if (fields.project_id !== undefined) {
    sets.push('project_id = ?');
    vals.push(fields.project_id || null);
  }
  vals.push(userId, taskId);
  db.prepare(`UPDATE tasks SET ${sets.join(', ')} WHERE user_id = ? AND task_id = ?`).run(...vals);
  return getTask(userId, taskId);
}

export function deleteTask(userId: string, taskId: string): boolean {
  const info = getDb()
    .prepare('DELETE FROM tasks WHERE user_id = ? AND task_id = ?')
    .run(userId, taskId);
  return info.changes > 0;
}

export function tasksOverview(userId: string) {
  const db = getDb();
  const today = new Date().toISOString().slice(0, 10);
  const counts = db
    .prepare(
      `SELECT status, COUNT(*) AS c FROM tasks WHERE user_id = ?
       GROUP BY status`,
    )
    .all(userId) as { status: TaskStatus; c: number }[];
  const dueToday = db
    .prepare(`SELECT COUNT(*) AS c FROM tasks WHERE user_id = ? AND due_date = ? AND status != 'completed'`)
    .get(userId, today) as { c: number };
  const upcoming = db
    .prepare(
      `SELECT * FROM tasks WHERE user_id = ? AND due_date > ? AND due_date <= ? AND status != 'completed'
       ORDER BY due_date ASC LIMIT 8`,
    )
    .all(userId, today, new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10)) as Task[];
  const byStatus: { todo: number; in_progress: number; completed: number } = { todo: 0, in_progress: 0, completed: 0 };
  for (const r of counts) byStatus[r.status as keyof typeof byStatus] = r.c;
  return { byStatus, dueToday: dueToday.c, upcoming };
}
