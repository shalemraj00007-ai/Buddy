import { getDb } from '../db';
import { nowIso, uid } from '../lib/ids';

export interface Project {
  project_id: string;
  user_id: string;
  name: string;
  description: string;
  status: string;
  color: string;
  created_at: string;
  updated_at: string;
  task_counts?: { todo: number; in_progress: number; completed: number };
  progress?: number;
}

export function createProject(
  userId: string,
  input: { name: string; description?: string; color?: string; status?: string },
): Project {
  const db = getDb();
  const now = nowIso();
  const id = uid();
  db.prepare(
    `INSERT INTO projects (project_id,user_id,name,description,status,color,created_at,updated_at)
     VALUES (?,?,?,?,?,?,?,?)`,
  ).run(
    id,
    userId,
    input.name,
    input.description ?? '',
    input.status ?? 'active',
    input.color ?? '#4F8CFF',
    now,
    now,
  );
  return getProject(userId, id)!;
}

export function getProject(userId: string, projectId: string): Project | null {
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM projects WHERE user_id = ? AND project_id = ?')
    .get(userId, projectId) as Project | undefined;
  if (!row) return null;
  const counts = db
    .prepare(
      `SELECT status, COUNT(*) AS c FROM tasks WHERE user_id = ? AND project_id = ? GROUP BY status`,
    )
    .all(userId, projectId) as { status: string; c: number }[];
  const byStatus: { todo: number; in_progress: number; completed: number } = { todo: 0, in_progress: 0, completed: 0 };
  for (const c of counts) byStatus[c.status as keyof typeof byStatus] = c.c;
  const total = byStatus.todo + byStatus.in_progress + byStatus.completed;
  return {
    ...row,
    task_counts: byStatus,
    progress: total ? Math.round((byStatus.completed / total) * 100) : 0,
  };
}

export function listProjects(userId: string): Project[] {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM projects WHERE user_id = ? ORDER BY updated_at DESC')
    .all(userId) as Project[];
  return rows.map((p) => getProject(userId, p.project_id)!);
}

export function updateProject(
  userId: string,
  projectId: string,
  fields: Partial<{ name: string; description: string; status: string; color: string }>,
): Project | null {
  const db = getDb();
  const sets: string[] = ['updated_at = ?'];
  const vals: unknown[] = [nowIso()];
  for (const k of ['name', 'description', 'status', 'color'] as const) {
    if (fields[k] !== undefined) {
      sets.push(`${k} = ?`);
      vals.push(fields[k]);
    }
  }
  vals.push(userId, projectId);
  db.prepare(`UPDATE projects SET ${sets.join(', ')} WHERE user_id = ? AND project_id = ?`).run(...vals);
  return getProject(userId, projectId);
}

export function deleteProject(userId: string, projectId: string): boolean {
  const info = getDb()
    .prepare('DELETE FROM projects WHERE user_id = ? AND project_id = ?')
    .run(userId, projectId);
  return info.changes > 0;
}

export function findProjectByKeyword(userId: string, text: string): Project | null {
  const projects = listProjects(userId);
  const low = text.toLowerCase();
  for (const p of projects) {
    const terms = p.name.toLowerCase().split(/[\s]+/);
    const words = low.split(/[^a-z0-9]+/);
    for (const term of terms) {
      if (term.length > 3 && words.includes(term)) return p;
    }
  }
  return null;
}
