import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// The dev server proxies /api to the Buddy backend so the browser only ever
// talks to one origin (no CORS issues, no keys exposed).
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    // Allow the sandbox preview host to load the app.
    allowedHosts: true,
    proxy: {
      '/api': {
        target: process.env.BUDDY_API_URL || 'http://localhost:4000',
        changeOrigin: true,
      },
    },
  },
});
