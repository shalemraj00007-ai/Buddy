import React, { useCallback, useEffect, useRef, useState } from 'react';

import { api, streamChat } from '../api/client';
import { useAuth } from '../store/AuthContext';
import { Composer, PendingAttachment } from '../components/Composer';
import { Markdown } from '../components/Markdown';

interface Attach {
  attachment_id: string;
  filename: string;
  kind: string;
}
interface ApiMessage {
  message_id: string;
  role: string;
  content: string;
  error: string | null;
  attachments: Attach[];
}
interface UIMessage {
  message_id: string;
  role: 'user' | 'assistant';
  content: string;
  error?: string;
  loading?: boolean;
  localAttachments?: PendingAttachment[];
  serverAttachments?: Attach[];
}
interface Conv {
  conversation_id: string;
  title: string;
  updated_at: string;
}

export function ChatPage() {
  const { user } = useAuth();
  const [convs, setConvs] = useState<Conv[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<UIMessage[]>([]);
  const [loadingConv, setLoadingConv] = useState(false);
  const [search, setSearch] = useState('');
  const [streaming, setStreaming] = useState(false);
  const [listOpen, setListOpen] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const activeRef = useRef<string | null>(null);
  activeRef.current = activeId;

  const loadConvs = useCallback(async () => {
    try {
      const d = await api<{ conversations: Conv[] }>(`/conversations${search ? `?q=${encodeURIComponent(search)}` : ''}`);
      setConvs(d.conversations);
    } catch {
      /* ignore */
    }
  }, [search]);

  useEffect(() => {
    const t = setTimeout(loadConvs, 200);
    return () => clearTimeout(t);
  }, [loadConvs]);

  const scrollToBottom = useCallback(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, []);

  const openConversation = async (id: string) => {
    setActiveId(id);
    setLoadingConv(true);
    try {
      const d = await api<{ messages: ApiMessage[] }>(`/conversations/${id}`);
      setMessages(
        d.messages
          .filter((m) => m.role !== 'system')
          .map((m) => ({
            message_id: m.message_id,
            role: m.role as any,
            content: m.content,
            error: m.error || undefined,
            serverAttachments: m.attachments,
          })),
      );
    } catch {
      setMessages([]);
    } finally {
      setLoadingConv(false);
      setTimeout(scrollToBottom, 30);
    }
  };

  const newChat = async () => {
    const d = await api<{ conversation: Conv }>('/conversations', { method: 'POST', body: {} });
    setConvs((p) => [d.conversation, ...p]);
    setActiveId(d.conversation.conversation_id);
    setMessages([]);
  };

  const renameConv = async (id: string, title: string) => {
    try {
      await api(`/conversations/${id}`, { method: 'PATCH', body: { title } });
      setConvs((p) => p.map((c) => (c.conversation_id === id ? { ...c, title } : c)));
    } catch {
      /* ignore */
    }
  };

  const deleteConv = async (id: string) => {
    try {
      await api(`/conversations/${id}`, { method: 'DELETE' });
      setConvs((p) => p.filter((c) => c.conversation_id !== id));
      if (activeId === id) {
        setActiveId(null);
        setMessages([]);
      }
    } catch {
      /* ignore */
    }
  };

  const runStream = useCallback(
    async (payload: any, afterUser: UIMessage) => {
      abortRef.current = new AbortController();
      setStreaming(true);
      // optimistic loading bubble
      const loadMsg: UIMessage = {
        message_id: `load-${Date.now()}`,
        role: 'assistant',
        content: '',
        loading: true,
      };
      setMessages((p) => [...p, afterUser, loadMsg]);
      let acc = '';
      let completed = false;
      try {
        await streamChat(
          payload,
          (e) => {
            if (e.type === 'meta') {
              if (e.conversation_id) activeRef.current = e.conversation_id;
            } else if (e.type === 'delta') {
              acc += e.text;
              setMessages((p) =>
                p.map((m) => (m.loading ? { ...m, content: acc, loading: false } : m)),
              );
              scrollToBottom();
            } else if (e.type === 'done') {
              completed = true;
              acc = e.text;
              setMessages((p) =>
                p.map((m) => (m.loading ? { ...m, content: e.text, loading: false } : m)),
              );
            } else if (e.type === 'error') {
              setMessages((p) =>
                p.map((m) =>
                  m.loading ? { ...m, loading: false, content: '', error: e.message } : m,
                ),
              );
            }
          },
          abortRef.current.signal,
        );
      } catch (err: any) {
        if (err?.name === 'AbortError') {
          // user stopped; keep partial
          setMessages((p) => p.map((m) => (m.loading ? { ...m, loading: false } : m)));
          completed = true;
        } else {
          setMessages((p) =>
            p.map((m) =>
              m.loading
                ? { ...m, loading: false, content: '', error: err.message || 'Request failed.' }
                : m,
            ),
          );
        }
      } finally {
        abortRef.current = null;
        setStreaming(false);
        if (completed) loadConvs();
      }
    },
    [loadConvs, scrollToBottom],
  );

  const send = useCallback(
    async (text: string, attachments: PendingAttachment[]) => {
      const convId = activeRef.current;
      if (convId === null) {
        const d = await api<{ conversation: Conv }>('/conversations', { method: 'POST', body: { title: text.slice(0, 40) } });
        activeRef.current = d.conversation.conversation_id;
        setActiveId(d.conversation.conversation_id);
        setConvs((p) => [d.conversation, ...p]);
      }
      const userMsg: UIMessage = {
        message_id: `u-${Date.now()}`,
        role: 'user',
        content: text,
        localAttachments: attachments,
      };
      await runStream(
        {
          conversation_id: activeRef.current,
          content: text,
          attachment_ids: attachments.map((a) => a.id),
        },
        userMsg,
      );
    },
    [runStream],
  );

  const regenerate = useCallback(
    (messageId: string) => {
      const idx = messages.findIndex((m) => m.message_id === messageId);
      const userMsg = messages[idx];
      if (!userMsg || userMsg.role !== 'user') return;
      // remove this user message and everything after
      const before = messages.slice(0, idx);
      setMessages(before);
      const userAttachments = userMsg.localAttachments?.map((a) => a.id) ?? [];
      const serverAtt = userMsg.serverAttachments?.map((a) => a.attachment_id) ?? [];
      const ids = [...new Set([...userAttachments, ...serverAtt])];
      void runStream(
        {
          conversation_id: activeRef.current,
          content: userMsg.content,
          attachment_ids: ids,
        },
        userMsg,
      );
    },
    [messages, runStream],
  );

  const editUser = useCallback(
    (messageId: string, newText: string) => {
      const idx = messages.findIndex((m) => m.message_id === messageId);
      if (idx < 0) return;
      const edited: UIMessage = { ...messages[idx], content: newText, message_id: `u-${Date.now()}` };
      const before = messages.slice(0, idx);
      setMessages(before);
      const serverAtt = messages[idx].serverAttachments?.map((a) => a.attachment_id) ?? [];
      void runStream(
        { conversation_id: activeRef.current, content: newText, attachment_ids: serverAtt },
        edited,
      );
    },
    [messages, runStream],
  );

  const stop = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  return (
    <div className="chat-layout">
      {listOpen && (
        <div className="conv-panel">
          <div className="conv-search">
            <input
              placeholder="Search conversations…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div style={{ padding: 10 }}>
            <button className="btn primary" style={{ width: '100%' }} onClick={newChat}>＋ New chat</button>
          </div>
          <div className="conv-list">
            {convs.length === 0 && <div className="empty">No conversations yet.</div>}
            {convs.map((c) => (
              <div
                key={c.conversation_id}
                className={`conv-item ${c.conversation_id === activeId ? 'active' : ''}`}
                onClick={() => openConversation(c.conversation_id)}
                title={c.title}
              >
                <span className="title">{c.title || 'New chat'}</span>
                <span
                  className="x"
                  role="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (confirm('Delete this conversation?')) deleteConv(c.conversation_id);
                  }}
                >
                  ×
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
      <div className="chat-main">
        <div className="main-header">
          <button className="btn ghost small" onClick={() => setListOpen((v) => !v)}>☰</button>
          <span className="muted">
            {activeId
              ? convs.find((c) => c.conversation_id === activeId)?.title || 'Chat'
              : 'Start a conversation'}
          </span>
          {activeId && (
            <button
              className="btn ghost small"
              onClick={() => {
                const title = prompt('Rename conversation:');
                if (title && title.trim()) renameConv(activeId, title.trim());
              }}
            >
              ✎
            </button>
          )}
        </div>
        <div className="chat-scroll" ref={scrollRef}>
          <div className="msgs">
            {messages.length === 0 && !loadingConv && (
              <div className="empty-state">
                <h2>Hey {user?.name?.split(' ')[0] || 'there'} 👋</h2>
                <p>
                  I'm Buddy. Ask me anything, or try:<br />
                  <span className="muted">"Add a task to finish the login system tomorrow"</span><br />
                  <span className="muted">"Remind me to study at 7pm"</span><br />
                  <span className="muted">"Remember I prefer dark mode"</span>
                </p>
              </div>
            )}
            {loadingConv && <div className="muted" style={{ textAlign: 'center' }}>Loading…</div>}
            {messages.map((m, i) => {
              if (m.role === 'assistant') {
                return (
                  <div className="msg assistant" key={m.message_id}>
                    <div className="avatar">B</div>
                    <div style={{ maxWidth: '100%' }}>
                      <div className="bubble assistant">
                        {m.loading ? (
                          <span className="typing"><span className="spin" /> thinking…</span>
                        ) : m.error ? (
                          <span style={{ color: 'var(--red)' }}>⚠️ {m.error}</span>
                        ) : (
                          <Markdown text={m.content} />
                        )}
                      </div>
                      {!m.loading && !m.error && (
                        <div className="msg-tools">
                          <button onClick={() => navigator.clipboard.writeText(m.content)}>copy</button>
                          <button
                            onClick={() => {
                              if ('speechSynthesis' in window) {
                                window.speechSynthesis.cancel();
                                const u = new SpeechSynthesisUtterance(m.content);
                                u.rate = 1;
                                window.speechSynthesis.speak(u);
                              }
                            }}
                          >
                            listen
                          </button>
                          {messages[i - 1]?.role === 'user' && (
                            <button onClick={() => regenerate(messages[i - 1].message_id)}>regenerate</button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              }
              return (
                <div className="msg user" key={m.message_id}>
                  <div style={{ maxWidth: '100%', textAlign: 'right' }}>
                    {(m.localAttachments?.length || 0) > 0 && (
                      <div className="attachments-row" style={{ justifyContent: 'flex-end' }}>
                        {m.localAttachments!.map((a) =>
                          a.kind === 'image' ? (
                            <img key={a.id} src={a.url} alt="" style={{ width: 80, height: 80, objectFit: 'cover', borderRadius: 8, border: '1px solid var(--border)' }} />
                          ) : (
                            <span key={a.id} className="attach-chip">📄 {a.filename}</span>
                          ),
                        )}
                      </div>
                    )}
                    <div className="bubble user">{m.content}</div>
                    {!streaming && messages[i + 1]?.role === 'assistant' && (
                      <div className="msg-tools" style={{ justifyContent: 'flex-end' }}>
                        <button
                          onClick={() => {
                            const t = prompt('Edit your message:', m.content);
                            if (t !== null && t.trim()) editUser(m.message_id, t.trim());
                          }}
                        >
                          edit
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        <Composer
          disabled={streaming}
          streaming={streaming}
          voiceEnabled={user?.voice_enabled}
          onSend={send}
          onStop={stop}
        />
      </div>
    </div>
  );
}
