import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

import { api } from '../api/client';

interface Daily {
  greeting: string;
  date: string;
  priorities: { title: string; due_date: string | null; project_name: string | null }[];
  reminders: { reminder_id: string; title: string; remind_at: string | null }[];
  goals: string[];
  projects: { name: string; progress: number; status: string; color: string }[];
  suggestion: string;
  stats: { tasks: { todo: number; in_progress: number; completed: number } };
}

export function DailyPage() {
  const [d, setD] = useState<Daily | null>(null);
  const [err, setErr] = useState('');

  useEffect(() => {
    api<{ daily: Daily }>('/daily')
      .then((r) => setD(r.daily))
      .catch((e) => setErr(e.message));
  }, []);

  if (err) return <div className="page-body"><div className="error-box">{err}</div></div>;
  if (!d) return <div className="page-body"><div className="spin" /></div>;

  return (
    <div className="page-body">
      <h1 style={{ margin: '4px 0 0' }}>{d.greeting}</h1>
      <div className="muted" style={{ marginBottom: 18 }}>{d.date}</div>

      <div className="grid cols-3" style={{ marginBottom: 14 }}>
        <div className="card">
          <div className="muted">Open tasks</div>
          <div style={{ fontSize: 30, fontWeight: 700 }}>{d.stats.tasks.todo + d.stats.tasks.in_progress}</div>
        </div>
        <div className="card">
          <div className="muted">In progress</div>
          <div style={{ fontSize: 30, fontWeight: 700 }}>{d.stats.tasks.in_progress}</div>
        </div>
        <div className="card">
          <div className="muted">Completed</div>
          <div style={{ fontSize: 30, fontWeight: 700, color: 'var(--green)' }}>{d.stats.tasks.completed}</div>
        </div>
      </div>

      <div className="grid cols-2">
        <div>
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Today's priorities</h3>
            {d.priorities.length === 0 && <div className="muted">Nothing urgent. Enjoy the calm ☕</div>}
            {d.priorities.map((p, i) => (
              <div key={i} className="list-row" style={{ border: 'none', padding: '8px 0', margin: 0 }}>
                <span>{i + 1}.</span>
                <div className="grow">
                  <div>{p.title}</div>
                  {p.project_name && <div className="tag">{p.project_name}</div>}
                </div>
                {p.due_date && <span className="muted small">{p.due_date}</span>}
              </div>
            ))}
          </div>

          <div className="card">
            <h3 style={{ marginTop: 0 }}>Upcoming reminders</h3>
            {d.reminders.length === 0 && <div className="muted">No upcoming reminders.</div>}
            {d.reminders.map((r) => (
              <div key={r.reminder_id} className="list-row" style={{ border: 'none', padding: '8px 0', margin: 0 }}>
                <span>⏰</span>
                <div className="grow">{r.title}</div>
                {r.remind_at && <span className="muted small">{new Date(r.remind_at).toLocaleString()}</span>}
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="card">
            <h3 style={{ marginTop: 0 }}>Projects</h3>
            {d.projects.length === 0 && <div className="muted">No projects yet. <Link to="/projects">Create one</Link>.</div>}
            {d.projects.map((p) => (
              <div key={p.name} style={{ marginBottom: 12 }}>
                <div className="row between">
                  <span style={{ fontWeight: 600 }}>{p.name}</span>
                  <span className="muted small">{p.progress}%</span>
                </div>
                <div className="progress"><div style={{ width: `${p.progress}%`, background: p.color }} /></div>
              </div>
            ))}
          </div>

          <div className="card">
            <h3 style={{ marginTop: 0 }}>Goals</h3>
            {d.goals.length === 0 && <div className="muted">No saved goals yet.</div>}
            <ul style={{ paddingLeft: 18, margin: 0 }}>
              {d.goals.map((g, i) => (
                <li key={i}>{g}</li>
              ))}
            </ul>
          </div>

          <div className="card" style={{ background: 'rgba(79,140,255,.08)', borderColor: 'var(--accent)' }}>
            <div className="muted" style={{ marginBottom: 4 }}>💡 Buddy's suggestion</div>
            <div>{d.suggestion}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
