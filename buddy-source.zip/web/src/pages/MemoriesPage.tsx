import React, { useCallback, useEffect, useState } from 'react';

import { api } from '../api/client';
import { useAuth } from '../store/AuthContext';

interface Memory {
  memory_id: string;
  category: string;
  content: string;
  importance: number;
  created_at: string;
  updated_at: string;
}
const CATS = ['Profile', 'Preference', 'Goal', 'Project', 'Skill', 'Important fact', 'Habit', 'Context'];

export function MemoriesPage() {
  const { user, updateUser } = useAuth();
  const [memories, setMemories] = useState<Memory[]>([]);
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('');
  const [editing, setEditing] = useState<null | Memory>(null);
  const [toast, setToast] = useState('');

  const load = useCallback(async () => {
    const params = new URLSearchParams();
    if (search) params.set('q', search);
    if (cat) params.set('category', cat);
    const d = await api<{ memories: Memory[] }>(`/memories?${params.toString()}`);
    setMemories(d.memories);
  }, [search, cat]);
  useEffect(() => { load(); }, [load]);

  const del = async (m: Memory) => {
    await api(`/memories/${m.memory_id}`, { method: 'DELETE' });
    load();
  };
  const deleteAll = async () => {
    if (!confirm('Delete ALL memories? This cannot be undone.')) return;
    await api('/memories', { method: 'DELETE' });
    load();
    setToast('All memories deleted.');
  };
  const saveEdit = async () => {
    if (!editing) return;
    await api(`/memories/${editing.memory_id}`, { method: 'PATCH', body: { content: editing.content, category: editing.category, importance: editing.importance } });
    setEditing(null);
    load();
  };

  const catColor: any = {
    Preference: 'green', Profile: '', Goal: 'amber', Project: '', Skill: 'amber', 'Important fact': 'red', Habit: '', Context: 'green',
  };

  return (
    <div className="page-body">
      <div className="row between" style={{ marginBottom: 16 }}>
        <h1 style={{ margin: 0 }}>Memories</h1>
        <div className="row">
          <span className="muted small">Memory {user?.memory_enabled ? 'on' : 'off'}</span>
          <label className="switch" style={{ display: 'inline-flex' }}>
            <input type="checkbox" checked={user?.memory_enabled} onChange={(e) => updateUser({ memory_enabled: e.target.checked })} />
            <span className="slider" />
          </label>
        </div>
      </div>

      <div className="row" style={{ marginBottom: 16 }}>
        <input placeholder="Search memories…" value={search} onChange={(e) => setSearch(e.target.value)} style={{ maxWidth: 260 }} />
        <select value={cat} onChange={(e) => setCat(e.target.value)} style={{ maxWidth: 180 }}>
          <option value="">All categories</option>
          {CATS.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <button className="btn danger" onClick={deleteAll} disabled={memories.length === 0}>Clear all</button>
      </div>

      {memories.length === 0 && (
        <div className="card"><div className="empty">
          No memories yet. Buddy saves useful facts automatically when you chat — try "Remember I prefer dark mode".
        </div></div>
      )}

      {memories.map((m) => (
        <div className="list-row" key={m.memory_id}>
          <div className="grow">
            <div className="row" style={{ gap: 8, marginBottom: 4 }}>
              <span className={`badge ${catColor[m.category] || ''}`}>{m.category}</span>
              {Array.from({ length: m.importance }).map((_, i) => <span key={i} style={{ color: 'var(--amber)' }}>★</span>)}
            </div>
            <div>{m.content}</div>
            <div className="muted small" style={{ marginTop: 4 }}>Updated {new Date(m.updated_at).toLocaleString()}</div>
          </div>
          <div className="row">
            <button className="btn small" onClick={() => setEditing(m)}>✎</button>
            <button className="btn small danger" onClick={() => del(m)}>🗑</button>
          </div>
        </div>
      ))}

      {editing && (
        <div className="modal-backdrop" onClick={() => setEditing(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Edit memory</h3>
            <div className="field"><label>Category</label>
              <select value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })}>
                {CATS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="field"><label>Content</label>
              <textarea value={editing.content} onChange={(e) => setEditing({ ...editing, content: e.target.value })} />
            </div>
            <div className="field"><label>Importance (1-5)</label>
              <input type="number" min={1} max={5} value={editing.importance} onChange={(e) => setEditing({ ...editing, importance: Number(e.target.value) })} />
            </div>
            <div className="row" style={{ justifyContent: 'flex-end' }}>
              <button className="btn ghost" onClick={() => setEditing(null)}>Cancel</button>
              <button className="btn primary" onClick={saveEdit}>Save</button>
            </div>
          </div>
        </div>
      )}
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
