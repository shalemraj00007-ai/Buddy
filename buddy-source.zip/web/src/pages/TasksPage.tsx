import React, { useCallback, useEffect, useState } from 'react';

import { api } from '../api/client';

interface Task {
  task_id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
  due_date: string | null;
  status: 'todo' | 'in_progress' | 'completed';
  project_id: string | null;
  project_name: string | null;
  created_at: string;
  completed_at: string | null;
}
interface Project { project_id: string; name: string; }

const PRIORITY_LABEL: any = { high: 'High', medium: 'Medium', low: 'Low' };

export function TasksPage() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [status, setStatus] = useState('');
  const [sort, setSort] = useState('created_at');
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState<null | { task?: Task }>(null);
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium', due_date: '', project_id: '' });
  const [toast, setToast] = useState('');

  const load = useCallback(async () => {
    const params = new URLSearchParams();
    if (status) params.set('status', status);
    if (sort) params.set('sort', sort);
    if (search) params.set('search', search);
    const d = await api<{ tasks: Task[] }>(`/tasks?${params.toString()}`);
    setTasks(d.tasks);
  }, [status, sort, search]);

  useEffect(() => {
    api<{ projects: Project[] }>('/projects').then((r) => setProjects(r.projects)).catch(() => {});
  }, []);

  useEffect(() => { load(); }, [load]);

  const openNew = () => {
    setForm({ title: '', description: '', priority: 'medium', due_date: '', project_id: '' });
    setModal({});
  };
  const openEdit = (t: Task) => {
    setForm({ title: t.title, description: t.description, priority: t.priority, due_date: t.due_date || '', project_id: t.project_id || '' });
    setModal({ task: t });
  };

  const save = async () => {
    if (!form.title.trim()) return;
    const body: any = {
      title: form.title.trim(),
      description: form.description,
      priority: form.priority,
      due_date: form.due_date || null,
      project_id: form.project_id || null,
    };
    try {
      if (modal?.task) await api(`/tasks/${modal.task.task_id}`, { method: 'PATCH', body });
      else await api('/tasks', { method: 'POST', body });
      setModal(null);
      load();
    } catch (e: any) {
      setToast(e.message);
    }
  };

  const updateTaskStatus = async (t: Task, s: Task['status']) => {
    await api(`/tasks/${t.task_id}`, { method: 'PATCH', body: { status: s } });
    load();
  };
  const del = async (t: Task) => {
    if (!confirm(`Delete task "${t.title}"?`)) return;
    await api(`/tasks/${t.task_id}`, { method: 'DELETE' });
    load();
  };

  const statusBadge: any = {
    todo: 'badge',
    in_progress: 'badge amber',
    completed: 'badge green',
  };
  const priorityBadge: any = { high: 'badge red', medium: 'badge amber', low: 'badge' };

  return (
    <div className="page-body">
      <div className="row between" style={{ marginBottom: 16 }}>
        <h1 style={{ margin: 0 }}>Tasks</h1>
        <button className="btn primary" onClick={openNew}>＋ New task</button>
      </div>

      <div className="row" style={{ marginBottom: 16 }}>
        <input placeholder="Search…" value={search} onChange={(e) => setSearch(e.target.value)} style={{ maxWidth: 220 }} />
        <select value={status} onChange={(e) => setStatusFilter(e.target.value)} style={{ maxWidth: 160 }}>
          <option value="">All statuses</option>
          <option value="todo">To do</option>
          <option value="in_progress">In progress</option>
          <option value="completed">Completed</option>
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value)} style={{ maxWidth: 160 }}>
          <option value="created_at">Newest</option>
          <option value="due_date">Due date</option>
          <option value="priority">Priority</option>
          <option value="title">Title</option>
        </select>
      </div>

      {tasks.length === 0 && <div className="card"><div className="empty">No tasks match.</div></div>}
      {tasks.map((t) => (
        <div className="list-row" key={t.task_id}>
          <input type="checkbox" className="checkbox" checked={t.status === 'completed'} onChange={() => updateTaskStatus(t, t.status === 'completed' ? 'todo' : 'completed')} />
          <div className="grow">
            <div style={{ textDecoration: t.status === 'completed' ? 'line-through' : 'none', color: t.status === 'completed' ? 'var(--text-faint)' : undefined, fontWeight: 600 }}>
              {t.title}
            </div>
            <div className="row" style={{ gap: 8, marginTop: 4 }}>
              <span className={statusBadge[t.status]}>{t.status.replace('_', ' ')}</span>
              <span className={priorityBadge[t.priority]}>{PRIORITY_LABEL[t.priority]}</span>
              {t.project_name && <span className="tag">{t.project_name}</span>}
              {t.due_date && <span className="muted small">📅 {t.due_date}</span>}
            </div>
          </div>
          <div className="row">
            {t.status !== 'in_progress' && t.status !== 'completed' && (
              <button className="btn small" onClick={() => updateTaskStatus(t, 'in_progress')}>Start</button>
            )}
            <button className="btn small" onClick={() => openEdit(t)}>✎</button>
            <button className="btn small danger" onClick={() => del(t)}>🗑</button>
          </div>
        </div>
      ))}

      {modal && (
        <div className="modal-backdrop" onClick={() => setModal(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>{modal.task ? 'Edit task' : 'New task'}</h3>
            <div className="field"><label>Title</label><input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} autoFocus /></div>
            <div className="field"><label>Description</label><textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
            <div className="grid cols-2">
              <div className="field"><label>Priority</label>
                <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                  <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option>
                </select>
              </div>
              <div className="field"><label>Due date</label><input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} /></div>
            </div>
            <div className="field"><label>Project (optional)</label>
              <select value={form.project_id} onChange={(e) => setForm({ ...form, project_id: e.target.value })}>
                <option value="">None</option>
                {projects.map((p) => <option key={p.project_id} value={p.project_id}>{p.name}</option>)}
              </select>
            </div>
            <div className="row" style={{ justifyContent: 'flex-end' }}>
              <button className="btn ghost" onClick={() => setModal(null)}>Cancel</button>
              <button className="btn primary" onClick={save}>Save</button>
            </div>
          </div>
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );

  function setStatusFilter(s: string) { setStatus(s); }
}
