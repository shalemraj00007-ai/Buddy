import React, { useCallback, useEffect, useState } from 'react';

import { api } from '../api/client';

interface Reminder {
  reminder_id: string;
  title: string;
  note: string;
  remind_at: string | null;
  recurring: { type: string; at?: string } | null;
  enabled: boolean;
}

export function RemindersPage() {
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [modal, setModal] = useState<null | { reminder?: Reminder }>(null);
  const [form, setForm] = useState({ title: '', note: '', when: 'once' as 'once' | 'daily' | 'weekly', date: '', time: '', weekday: '1' });
  const [toast, setToast] = useState('');

  const load = useCallback(async () => {
    const d = await api<{ reminders: Reminder[] }>('/reminders');
    setReminders(d.reminders);
  }, []);
  useEffect(() => { load(); }, [load]);

  const openNew = () => setForm({ title: '', note: '', when: 'once', date: '', time: '09:00', weekday: '1' });

  const save = async () => {
    if (!form.title.trim()) return;
    let remind_at: string | null = null;
    let recurring: any = null;
    if (form.when === 'once') {
      const iso = form.date && form.time ? new Date(`${form.date}T${form.time}`).toISOString() : null;
      remind_at = iso;
    } else if (form.when === 'daily') {
      recurring = { type: 'daily', at: form.time || '09:00' };
      remind_at = new Date(`${new Date().toISOString().slice(0, 10)}T${form.time || '09:00'}`).toISOString();
    } else {
      recurring = { type: 'weekly', at: form.time || '09:00', days: [Number(form.weekday)] };
      remind_at = new Date(`${new Date().toISOString().slice(0, 10)}T${form.time || '09:00'}`).toISOString();
    }
    const body = { title: form.title.trim(), note: form.note, remind_at, recurring };
    try {
      if (modal?.reminder) await api(`/reminders/${modal.reminder.reminder_id}`, { method: 'PATCH', body });
      else await api('/reminders', { method: 'POST', body });
      setModal(null);
      load();
    } catch (e: any) { setToast(e.message); }
  };

  const toggle = async (r: Reminder) => {
    await api(`/reminders/${r.reminder_id}`, { method: 'PATCH', body: { enabled: !r.enabled } });
    load();
  };
  const del = async (r: Reminder) => {
    await api(`/reminders/${r.reminder_id}`, { method: 'DELETE' });
    load();
  };

  return (
    <div className="page-body">
      <div className="row between" style={{ marginBottom: 16 }}>
        <h1 style={{ margin: 0 }}>Reminders</h1>
        <button className="btn primary" onClick={openNew}>＋ New reminder</button>
      </div>

      {reminders.length === 0 && <div className="card"><div className="empty">No reminders. Try telling Buddy "Remind me to study at 7pm".</div></div>}

      {reminders.map((r) => (
        <div className="list-row" key={r.reminder_id}>
          <span style={{ fontSize: 20, opacity: r.enabled ? 1 : 0.4 }}>⏰</span>
          <div className="grow">
            <div style={{ fontWeight: 600, textDecoration: r.enabled ? undefined : 'line-through', opacity: r.enabled ? 1 : 0.6 }}>
              {r.title}
            </div>
            <div className="muted small">
              {r.recurring
                ? `Repeats ${r.recurring.type}${r.recurring.at ? ` at ${r.recurring.at}` : ''}`
                : r.remind_at
                ? new Date(r.remind_at).toLocaleString()
                : 'No time set'}
              {r.note && ` — ${r.note}`}
            </div>
          </div>
          <div className="row">
            <label className="switch">
              <input type="checkbox" checked={r.enabled} onChange={() => toggle(r)} />
              <span className="slider" />
            </label>
            <button className="btn small danger" onClick={() => del(r)}>🗑</button>
          </div>
        </div>
      ))}

      {modal && (
        <div className="modal-backdrop" onClick={() => setModal(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>New reminder</h3>
            <div className="field"><label>What to remind about</label><input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} autoFocus /></div>
            <div className="field"><label>Note (optional)</label><input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></div>
            <div className="field"><label>Repeat</label>
              <select value={form.when} onChange={(e) => setForm({ ...form, when: e.target.value as any })}>
                <option value="once">Once</option><option value="daily">Every day</option><option value="weekly">Every week</option>
              </select>
            </div>
            {form.when === 'once' && (
              <div className="grid cols-2">
                <div className="field"><label>Date</label><input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
                <div className="field"><label>Time</label><input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} /></div>
              </div>
            )}
            {form.when === 'weekly' && (
              <div className="field"><label>Weekday</label>
                <select value={form.weekday} onChange={(e) => setForm({ ...form, weekday: e.target.value })}>
                  {['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'].map((d, i) => <option key={i} value={i}>{d}</option>)}
                </select>
              </div>
            )}
            {(form.when === 'daily' || form.when === 'weekly') && (
              <div className="field"><label>Time</label><input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} /></div>
            )}
            <div className="row" style={{ justifyContent: 'flex-end' }}>
              <button className="btn ghost" onClick={() => setModal(null)}>Cancel</button>
              <button className="btn primary" onClick={save}>Save</button>
            </div>
          </div>
        </div>
      )}
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
