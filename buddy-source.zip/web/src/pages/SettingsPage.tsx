import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { api } from '../api/client';
import { useAuth } from '../store/AuthContext';

export function SettingsPage() {
  const { user, updateUser, logout } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState(user?.name || '');
  const [providers, setProviders] = useState<{ id: string; label: string; configured: boolean }[]>([]);
  const [toast, setToast] = useState('');

  useEffect(() => {
    api('/providers').then((r: any) => setProviders(r.providers || [])).catch(() => {});
  }, []);

  const saveProfile = async () => {
    await updateUser({ name: name.trim() || user!.name });
    setToast('Profile saved.');
  };

  const deleteAccount = async () => {
    if (!confirm('Delete your account and ALL data? This cannot be undone.')) return;
    await api('/account', { method: 'DELETE' });
    logout();
    navigate('/login');
  };

  if (!user) return null;

  const Row = ({ children }: any) => (
    <div className="list-row"><div className="grow">{children[0]}</div>{children[1]}</div>
  );
  const Toggle = ({ label, sub, checked, onChange }: any) => (
    <Row>
      <div><div style={{ fontWeight: 600 }}>{label}</div>{sub && <div className="muted small">{sub}</div>}</div>
      <label className="switch"><input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} /><span className="slider" /></label>
    </Row>
  );

  return (
    <div className="page-body">
      <h1 style={{ margin: '0 0 16px' }}>Settings</h1>
      <div className="grid cols-2" style={{ alignItems: 'start' }}>
        <div>
          <div className="card" style={{ marginBottom: 14 }}>
            <h3 style={{ marginTop: 0 }}>Profile</h3>
            <div className="row" style={{ marginBottom: 14 }}>
              <div className="avatar" style={{ width: 48, height: 48, fontSize: 20 }}>{user.name[0]?.toUpperCase()}</div>
              <div>
                <div className="muted small">{user.email}</div>
              </div>
            </div>
            <div className="field"><label>Name</label><input value={name} onChange={(e) => setName(e.target.value)} /></div>
            <button className="btn primary" onClick={saveProfile}>Save profile</button>
          </div>

          <div className="card" style={{ marginBottom: 14 }}>
            <h3 style={{ marginTop: 0 }}>AI assistant</h3>
            <div className="field"><label>Response style</label>
              <select value={user.ai_personality} onChange={(e) => updateUser({ ai_personality: e.target.value })}>
                <option value="balanced">Balanced</option>
                <option value="concise">Concise</option>
                <option value="detailed">Detailed</option>
                <option value="technical">Technical</option>
                <option value="casual">Casual</option>
              </select>
            </div>
            <div className="field"><label>Language</label>
              <select value={user.language} onChange={(e) => updateUser({ language: e.target.value })}>
                <option value="en">English</option>
                <option value="hi">Hindi</option>
                <option value="es">Spanish</option>
                <option value="fr">French</option>
                <option value="de">German</option>
              </select>
            </div>
            <div className="muted small" style={{ marginTop: 6 }}>Model provider:</div>
            {providers.map((p) => (
              <div key={p.id} className="row" style={{ gap: 8, marginTop: 4 }}>
                <span className={p.configured ? 'badge green' : 'badge'}>{p.configured ? '●' : '○'}</span>
                <span className="small">{p.label}</span>
                {!p.configured && <span className="muted small">not configured</span>}
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="card" style={{ marginBottom: 14 }}>
            <h3 style={{ marginTop: 0 }}>Memory</h3>
            <Toggle label="Long-term memory" sub="Buddy remembers useful facts about you across conversations" checked={user.memory_enabled} onChange={(v: boolean) => updateUser({ memory_enabled: v })} />
          </div>

          <div className="card" style={{ marginBottom: 14 }}>
            <h3 style={{ marginTop: 0 }}>Voice</h3>
            <Toggle label="Enable voice input" sub="Use the microphone to speak to Buddy" checked={user.voice_enabled} onChange={(v: boolean) => updateUser({ voice_enabled: v })} />
            <Toggle label="Enable voice replies" sub="Buddy speaks responses using your browser's voice" checked={user.voice_enabled} onChange={(v: boolean) => updateUser({ voice_enabled: v })} />
            <div className="muted small">Voice replies use the text-to-speech in your browser. You can play any response with the "listen" button under a message.</div>
          </div>

          <div className="card" style={{ marginBottom: 14 }}>
            <h3 style={{ marginTop: 0 }}>Notifications</h3>
            <Toggle label="Reminder notifications" sub="Buddy checks and fires reminders on the server" checked={user.notifications_enabled} onChange={(v: boolean) => updateUser({ notifications_enabled: v })} />
            <div className="muted small">Delivery to your device uses the platform notification system; it's wired to the server scheduler.</div>
          </div>

          <div className="card" style={{ marginBottom: 14 }}>
            <h3 style={{ marginTop: 0 }}>Appearance</h3>
            <div className="field"><label>Theme</label>
              <select value={user.theme} onChange={(e) => updateUser({ theme: e.target.value })}>
                <option value="system">System</option>
                <option value="dark">Dark</option>
                <option value="light">Light</option>
              </select>
            </div>
          </div>

          <div className="card" style={{ marginBottom: 14, borderColor: 'var(--red)' }}>
            <h3 style={{ marginTop: 0, color: 'var(--red)' }}>Privacy & data</h3>
            <div className="muted" style={{ marginBottom: 10 }}>
              Your data is stored on your own server (SQLite). Conversations, memories, files, tasks and projects are only accessible to your account.
            </div>
            <button className="btn danger" onClick={deleteAccount}>Delete my account &amp; all data</button>
          </div>
        </div>
      </div>
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
