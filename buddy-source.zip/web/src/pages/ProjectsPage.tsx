import React, { useCallback, useEffect, useState } from 'react';

import { api } from '../api/client';

interface Project {
  project_id: string;
  name: string;
  description: string;
  status: string;
  color: string;
  progress: number;
  task_counts?: { todo: number; in_progress: number; completed: number };
}
interface Task {
  task_id: string;
  title: string;
  status: string;
  priority: string;
  due_date: string | null;
}
const COLORS = ['#4F8CFF', '#2ea043', '#d29922', '#f85149', '#8a63d2', '#e36209'];

export function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [modal, setModal] = useState<null | { project?: Project }>(null);
  const [openTasks, setOpenTasks] = useState<Record<string, Task[]>>({});
  const [form, setForm] = useState({ name: '', description: '', color: COLORS[0], status: 'active' });
  const [toast, setToast] = useState('');

  const load = useCallback(async () => {
    const d = await api<{ projects: Project[] }>('/projects');
    setProjects(d.projects);
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.name.trim()) return;
    const body: any = { name: form.name.trim(), description: form.description, color: form.color, status: form.status };
    try {
      if (modal?.project) await api(`/projects/${modal.project.project_id}`, { method: 'PATCH', body });
      else await api('/projects', { method: 'POST', body });
      setModal(null);
      load();
    } catch (e: any) { setToast(e.message); }
  };
  const del = async (p: Project) => {
    if (!confirm(`Delete project "${p.name}" and its tasks?`)) return;
    await api(`/projects/${p.project_id}`, { method: 'DELETE' });
    load();
  };
  const toggleTasks = async (p: Project) => {
    if (openTasks[p.project_id]) {
      setOpenTasks((o) => { const n = { ...o }; delete n[p.project_id]; return n; });
      return;
    }
    const d = await api<{ tasks: Task[] }>(`/projects/${p.project_id}`);
    setOpenTasks((o) => ({ ...o, [p.project_id]: d.tasks }));
  };
  const markTask = async (taskId: string, status: string) => {
    await api(`/tasks/${taskId}`, { method: 'PATCH', body: { status } });
    load();
    setOpenTasks({});
  };

  const statusBadge: any = { active: 'badge green', paused: 'badge amber', completed: 'badge', archived: 'badge' };

  return (
    <div className="page-body">
      <div className="row between" style={{ marginBottom: 16 }}>
        <h1 style={{ margin: 0 }}>Projects</h1>
        <button className="btn primary" onClick={() => { setForm({ name: '', description: '', color: COLORS[0], status: 'active' }); setModal({}); }}>＋ New project</button>
      </div>

      {projects.length === 0 && <div className="card"><div className="empty">No projects yet. Create one to organize your work.</div></div>}

      <div className="grid cols-2">
        {projects.map((p) => (
          <div className="card" key={p.project_id}>
            <div className="row between">
              <div className="row" style={{ gap: 8 }}>
                <span style={{ width: 12, height: 12, borderRadius: 4, background: p.color, display: 'inline-block' }} />
                <h3 style={{ margin: 0, fontSize: 17 }}>{p.name}</h3>
                <span className={statusBadge[p.status]}>{p.status}</span>
              </div>
              <div className="row">
                <button className="btn small" onClick={() => { setForm({ name: p.name, description: p.description, color: p.color, status: p.status }); setModal({ project: p }); }}>✎</button>
                <button className="btn small danger" onClick={() => del(p)}>🗑</button>
              </div>
            </div>
            {p.description && <div className="muted" style={{ marginTop: 6 }}>{p.description}</div>}
            <div className="row between" style={{ marginTop: 12 }}>
              <span className="muted small">{p.progress}% complete</span>
              <button className="btn small ghost" onClick={() => toggleTasks(p)}>
                {openTasks[p.project_id] ? 'Hide tasks ▴' : 'View tasks ▾'}
              </button>
            </div>
            <div className="progress" style={{ marginTop: 6 }}><div style={{ width: `${p.progress}%`, background: p.color }} /></div>
            {openTasks[p.project_id] && (
              <div style={{ marginTop: 12 }}>
                {openTasks[p.project_id].length === 0 && <div className="muted small">No tasks in this project.</div>}
                {openTasks[p.project_id].map((t) => (
                  <div className="list-row" key={t.task_id} style={{ padding: '8px 10px', marginBottom: 6 }}>
                    <input type="checkbox" className="checkbox" checked={t.status === 'completed'} onChange={() => markTask(t.task_id, t.status === 'completed' ? 'todo' : 'completed')} />
                    <div className="grow">{t.title}</div>
                    <span className={t.priority === 'high' ? 'badge red' : t.priority === 'medium' ? 'badge amber' : 'badge'}>{t.priority}</span>
                    {t.due_date && <span className="muted small">{t.due_date}</span>}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {modal && (
        <div className="modal-backdrop" onClick={() => setModal(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>{modal.project ? 'Edit project' : 'New project'}</h3>
            <div className="field"><label>Name</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} autoFocus /></div>
            <div className="field"><label>Description</label><textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
            <div className="field">
              <label>Color</label>
              <div className="row">
                {COLORS.map((c) => (
                  <button key={c} onClick={() => setForm({ ...form, color: c })}
                    style={{ width: 28, height: 28, borderRadius: 8, background: c, border: form.color === c ? '3px solid #fff' : 'none', cursor: 'pointer' }} />
                ))}
              </div>
            </div>
            <div className="field"><label>Status</label>
              <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                <option value="active">Active</option><option value="paused">Paused</option><option value="completed">Completed</option><option value="archived">Archived</option>
              </select>
            </div>
            <div className="row" style={{ justifyContent: 'flex-end' }}>
              <button className="btn ghost" onClick={() => setModal(null)}>Cancel</button>
              <button className="btn primary" onClick={save}>Save</button>
            </div>
          </div>
        </div>
      )}
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
