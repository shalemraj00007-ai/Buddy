import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import hljs from 'highlight.js';
import 'highlight.js/styles/github-dark.css';

function CodeBlock({ language, code }: { language: string; code: string }) {
  let html = code;
  try {
    if (language && hljs.getLanguage(language)) {
      html = hljs.highlight(code, { language }).value;
    } else {
      html = hljs.highlightAuto(code).value;
    }
  } catch {
    html = code.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      /* ignore */
    }
  };
  return (
    <div style={{ margin: '0.6em 0' }}>
      <div className="code-header">
        <span>{language || 'text'}</span>
        <button onClick={copy}>⧉ copy</button>
      </div>
      <pre>
        <code dangerouslySetInnerHTML={{ __html: html }} />
      </pre>
    </div>
  );
}

export function Markdown({ text }: { text: string }) {
  return (
    <div className="md">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          code({ inline, className, children, ...props }: any) {
            const match = /language-(\w+)/.exec(className || '');
            const code = String(children ?? '').replace(/\n$/, '');
            if (inline || !match) {
              return <code className={className} {...props}>{children}</code>;
            }
            return <CodeBlock language={match[1]} code={code} />;
          },
          a({ children, href }) {
            return (
              <a href={href} target="_blank" rel="noreferrer noopener">
                {children}
              </a>
            );
          },
        }}
      >
        {text}
      </ReactMarkdown>
    </div>
  );
}
