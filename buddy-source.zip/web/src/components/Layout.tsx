import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';

import { useAuth } from '../store/AuthContext';

const NAV = [
  { to: '/', label: 'Chat', ico: '💬', end: false },
  { to: '/daily', label: 'Daily', ico: '🌅', end: false },
  { to: '/tasks', label: 'Tasks', ico: '✅', end: false },
  { to: '/projects', label: 'Projects', ico: '🗂️', end: false },
  { to: '/memories', label: 'Memories', ico: '🧠', end: false },
  { to: '/reminders', label: 'Reminders', ico: '⏰', end: false },
  { to: '/settings', label: 'Settings', ico: '⚙️', end: false },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="brand">
            <div className="logo">B</div>
            Buddy
          </div>
        </div>
        <nav className="sidebar-nav">
          <div className="nav-section">Personal assistant</div>
          {NAV.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
              onClick={() => setMobileOpen(false)}
            >
              <span className="ico">{n.ico}</span>
              {n.label}
            </NavLink>
          ))}
          <div className="nav-section">Account</div>
          <button
            className="nav-item"
            onClick={() => {
              logout();
              navigate('/login');
            }}
          >
            <span className="ico">↪</span> Sign out
          </button>
        </nav>
        <div className="sidebar-footer">
          <div className="user-chip">
            <div className="avatar">{(user?.name || '?')[0]?.toUpperCase()}</div>
            <div style={{ minWidth: 0 }}>
              <div className="name">{user?.name}</div>
              <div className="email">{user?.email}</div>
            </div>
          </div>
        </div>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
