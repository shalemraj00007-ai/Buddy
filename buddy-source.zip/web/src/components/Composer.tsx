import React, { useEffect, useRef, useState } from 'react';

import { api } from '../api/client';

export interface PendingAttachment {
  id: string;
  filename: string;
  kind: 'image' | 'document';
  url?: string;
  size: number;
}

interface Props {
  disabled?: boolean;
  streaming?: boolean;
  voiceEnabled?: boolean;
  onSend: (text: string, attachments: PendingAttachment[]) => void;
  onStop: () => void;
}

const SUPPORTED = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.pdf', '.docx', '.txt', '.md', '.csv', '.json'];

export function Composer({ disabled, streaming, voiceEnabled, onSend, onStop }: Props) {
  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<PendingAttachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [micErr, setMicErr] = useState<string | null>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const recogRef = useRef<any>(null);

  const canSend = (text.trim().length > 0 || attachments.length > 0) && !disabled && !uploading;

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    const form = new FormData();
    for (const f of Array.from(files)) {
      const ext = '.' + (f.name.split('.').pop() || '').toLowerCase();
      if (!SUPPORTED.includes(ext)) continue;
      form.append('files', f);
    }
    try {
      const res = await api<{ attachments: any[] }>('/files', { method: 'POST', body: form });
      const mapped = res.attachments.map((a) => ({
        id: a.attachment_id,
        filename: a.filename,
        kind: a.kind,
        url: a.kind === 'image' ? `/api/files/${a.attachment_id}/file` : undefined,
        size: a.size,
      }));
      setAttachments((prev) => [...prev, ...mapped]);
    } catch (e: any) {
      alert(e.message || 'Upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const toggleMic = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) {
      setMicErr('Speech recognition is not supported in this browser.');
      return;
    }
    if (recording) {
      recogRef.current?.stop();
      setRecording(false);
      return;
    }
    try {
      const rec = new SR();
      rec.lang = 'en-US';
      rec.interimResults = true;
      rec.continuous = false;
      rec.onresult = (e: any) => {
        let transcript = '';
        for (let i = 0; i < e.results.length; i++) transcript += e.results[i][0].transcript;
        setTranscribing(true);
        setText((prev) => (prev ? prev + ' ' : '') + transcript);
      };
      rec.onerror = (e: any) => {
        setMicErr(e.error === 'not-allowed' ? 'Microphone permission denied.' : `Voice input error: ${e.error}`);
        setRecording(false);
      };
      rec.onend = () => {
        setRecording(false);
        setTranscribing(false);
      };
      rec.start();
      recogRef.current = rec;
      setRecording(true);
      setMicErr(null);
    } catch (e: any) {
      setMicErr(String(e?.message || e));
    }
  };

  const submit = () => {
    if (!canSend) return;
    onSend(text.trim(), attachments);
    setText('');
    setAttachments([]);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        const t = e.target as HTMLElement;
        if (t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT')) return;
        taRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div className="composer-wrap">
      <div className="attachments-row">
        {attachments.map((a) => (
          <span className="attach-chip" key={a.id}>
            {a.kind === 'image' ? <img src={a.url} alt="" /> : <span>📄</span>}
            <span>{a.filename}</span>
            <button onClick={() => setAttachments((p) => p.filter((x) => x.id !== a.id))}>×</button>
          </span>
        ))}
        {uploading && <span className="attach-chip"><span className="spin" /> uploading…</span>}
      </div>
      <div className="composer">
        <textarea
          ref={taRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={recording ? 'Listening…' : 'Message Buddy… (Shift+Enter for newline)'}
          rows={1}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
        />
        <label className="icon-btn" title="Attach file/image" style={{ cursor: 'pointer' }}>
          <span>＋</span>
          <input
            type="file"
            multiple
            accept={SUPPORTED.join(',')}
            style={{ display: 'none' }}
            onChange={(e) => handleFiles(e.target.files)}
          />
        </label>
        {voiceEnabled && (
          <button className={`icon-btn ${recording ? 'rec' : ''}`} onClick={toggleMic} title="Voice input" disabled={transcribing}>
            {recording ? '⏺' : transcribing ? <span className="spin" /> : '🎤'}
          </button>
        )}
        {streaming ? (
          <button className="icon-btn stop" onClick={onStop} title="Stop generating">■</button>
        ) : (
          <button className="icon-btn send" onClick={submit} disabled={!canSend} title="Send">➤</button>
        )}
      </div>
      {micErr && <div className="muted" style={{ maxWidth: 860, margin: '6px auto 0', color: 'var(--red)', fontSize: 12 }}>{micErr}</div>}
    </div>
  );
}
