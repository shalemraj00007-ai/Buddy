import React, { createContext, useContext, useEffect, useState } from 'react';

import { api, getToken, setToken } from '../api/client';

export interface User {
  user_id: string;
  email: string;
  name: string;
  language: string;
  theme: string;
  ai_personality: string;
  memory_enabled: boolean;
  voice_enabled: boolean;
  voice_id: string | null;
  notifications_enabled: boolean;
}

interface AuthCtx {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  updateUser: (patch: Partial<User>) => Promise<void>;
  refresh: () => Promise<void>;
}

const Ctx = createContext<AuthCtx>(null as any);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    if (!getToken()) {
      setUser(null);
      setLoading(false);
      return;
    }
    try {
      const d = await api<{ user: User }>('/me');
      setUser(d.user);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  const login = async (email: string, password: string) => {
    const d = await api<{ user: User; token: string }>('/login', { method: 'POST', body: { email, password }, auth: false });
    setToken(d.token);
    setUser(d.user);
  };

  const register = async (name: string, email: string, password: string) => {
    const d = await api<{ user: User; token: string }>('/register', { method: 'POST', body: { name, email, password }, auth: false });
    setToken(d.token);
    setUser(d.user);
  };

  const logout = () => {
    setToken(null);
    setUser(null);
  };

  const updateUser = async (patch: Partial<User>) => {
    const d = await api<{ user: User }>('/settings', { method: 'PATCH', body: patch });
    setUser(d.user);
  };

  return (
    <Ctx.Provider value={{ user, loading, login, register, logout, updateUser, refresh }}>
      {children}
    </Ctx.Provider>
  );
}

export const useAuth = () => useContext(Ctx);
