// Thin fetch wrapper. The token is kept in localStorage and attached to every
// request. No API keys ever live on the client — the backend handles those.

const TOKEN_KEY = 'buddy.token';

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}
export function setToken(t: string | null) {
  if (t) localStorage.setItem(TOKEN_KEY, t);
  else localStorage.removeItem(TOKEN_KEY);
}

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export async function api<T = any>(
  path: string,
  opts: { method?: string; body?: any; auth?: boolean } = {},
): Promise<T> {
  const headers: Record<string, string> = {};
  if (opts.body !== undefined && !(opts.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }
  if (opts.auth !== false) {
    const t = getToken();
    if (t) headers['Authorization'] = `Bearer ${t}`;
  }
  const res = await fetch(`/api${path}`, {
    method: opts.method || 'GET',
    headers,
    body:
      opts.body instanceof FormData
        ? opts.body
        : opts.body !== undefined
        ? JSON.stringify(opts.body)
        : undefined,
  });
  if (!res.ok) {
    let msg = 'Request failed.';
    try {
      const data = await res.json();
      if (data?.error) msg = data.error;
    } catch {
      /* ignore */
    }
    if (res.status === 401) setToken(null);
    throw new ApiError(res.status, msg);
  }
  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

// --- streaming chat (SSE) ---
export type ChatEvent =
  | { type: 'meta'; conversation_id: string; message_id: string }
  | { type: 'delta'; text: string }
  | { type: 'done'; text: string; toolText?: string }
  | { type: 'error'; message: string };

export async function streamChat(
  payload: {
    conversation_id?: string;
    content?: string;
    attachment_ids?: string[];
    regenerate_message_id?: string;
  },
  onEvent: (e: ChatEvent) => void,
  signal?: AbortSignal,
): Promise<void> {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${getToken()}`,
    },
    body: JSON.stringify(payload),
    signal,
  });
  if (!res.ok || !res.body) {
    let msg = 'Could not reach the assistant.';
    try {
      const d = await res.json();
      if (d?.error) msg = d.error;
    } catch {
      /* ignore */
    }
    throw new ApiError(res.status, msg);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const parts = buffer.split('\n\n');
    buffer = parts.pop() ?? '';
    for (const part of parts) {
      const lines = part.split('\n');
      let event = 'message';
      let data = '';
      for (const line of lines) {
        if (line.startsWith('event:')) event = line.slice(6).trim();
        else if (line.startsWith('data:')) data += line.slice(5).trim();
      }
      if (!data) continue;
      try {
        const parsed = JSON.parse(data);
        if (event === 'meta') onEvent({ type: 'meta', ...parsed });
        else if (event === 'delta') onEvent({ type: 'delta', text: parsed.text });
        else if (event === 'done') onEvent({ type: 'done', text: parsed.text, toolText: parsed.toolText });
        else if (event === 'error') onEvent({ type: 'error', message: parsed.message });
      } catch {
        /* ignore partial */
      }
    }
  }
}


